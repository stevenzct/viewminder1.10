﻿namespace viewminder1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.btnArchive = new Guna.UI2.WinForms.Guna2Button();
            this.btnSms = new Guna.UI2.WinForms.Guna2Button();
            this.btnWatching = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2ControlBox3 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ControlBox2 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(this.components);
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox7 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel5 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlLabel14 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlLabel13 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.monthCalendar2 = new System.Windows.Forms.MonthCalendar();
            this.guna2PictureBox12 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox13 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox14 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox15 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.guna2Panel17 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel15 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlLabel23 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel24 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel16 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel14 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel10 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox5 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox6 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.guna2Panel18 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel19 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlLabel25 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel26 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel20 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel21 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel22 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2PictureBox8 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox9 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox10 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox11 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.guna2Panel23 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel24 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlLabel28 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel26 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel27 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2PictureBox16 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox17 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox18 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox19 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.guna2Button9 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel7 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel11 = new Guna.UI2.WinForms.Guna2Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.guna2Separator5 = new Guna.UI2.WinForms.Guna2Separator();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.guna2Separator4 = new Guna.UI2.WinForms.Guna2Separator();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.guna2Separator2 = new Guna.UI2.WinForms.Guna2Separator();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button10 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button11 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel8 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel12 = new Guna.UI2.WinForms.Guna2Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.guna2Separator7 = new Guna.UI2.WinForms.Guna2Separator();
            this.label22 = new System.Windows.Forms.Label();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.guna2Separator6 = new Guna.UI2.WinForms.Guna2Separator();
            this.label19 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.guna2Separator3 = new Guna.UI2.WinForms.Guna2Separator();
            this.label7 = new System.Windows.Forms.Label();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button12 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button13 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel9 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel13 = new Guna.UI2.WinForms.Guna2Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.guna2Separator8 = new Guna.UI2.WinForms.Guna2Separator();
            this.label27 = new System.Windows.Forms.Label();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.guna2Separator9 = new Guna.UI2.WinForms.Guna2Separator();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.guna2Separator10 = new Guna.UI2.WinForms.Guna2Separator();
            this.label33 = new System.Windows.Forms.Label();
            this.guna2HtmlLabel11 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel12 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.guna2Button15 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2TextBox7 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel16 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox6 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel17 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox5 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel18 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox4 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel19 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox3 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel20 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel21 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel22 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button16 = new Guna.UI2.WinForms.Guna2Button();
            this.label52 = new System.Windows.Forms.Label();
            this.guna2HtmlLabel15 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button14 = new Guna.UI2.WinForms.Guna2Button();
            this.pnlContent = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel25 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Button22 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button21 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button20 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button19 = new Guna.UI2.WinForms.Guna2Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.guna2Button18 = new Guna.UI2.WinForms.Guna2Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.btnPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.guna2Panel2.SuspendLayout();
            this.guna2Panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox7)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox15)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox6)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox11)).BeginInit();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox19)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.guna2Panel7.SuspendLayout();
            this.guna2Panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.guna2Panel8.SuspendLayout();
            this.guna2Panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.guna2Panel9.SuspendLayout();
            this.guna2Panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.pnlContent.SuspendLayout();
            this.guna2Panel25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPanel
            // 
            this.btnPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.btnPanel.Controls.Add(this.guna2Button8);
            this.btnPanel.Controls.Add(this.guna2Button7);
            this.btnPanel.Controls.Add(this.guna2Button2);
            this.btnPanel.Controls.Add(this.btnArchive);
            this.btnPanel.Controls.Add(this.btnSms);
            this.btnPanel.Controls.Add(this.btnWatching);
            this.btnPanel.Controls.Add(this.guna2HtmlLabel2);
            this.btnPanel.Controls.Add(this.guna2PictureBox1);
            this.btnPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnPanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnPanel.Location = new System.Drawing.Point(0, 0);
            this.btnPanel.Name = "btnPanel";
            this.btnPanel.ShadowDecoration.Parent = this.btnPanel;
            this.btnPanel.Size = new System.Drawing.Size(244, 858);
            this.btnPanel.TabIndex = 0;
            this.btnPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.Guna2Panel1_Paint_1);
            // 
            // guna2Button8
            // 
            this.guna2Button8.BorderRadius = 9;
            this.guna2Button8.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button8.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button8.CheckedState.Parent = this.guna2Button8;
            this.guna2Button8.CustomImages.Parent = this.guna2Button8;
            this.guna2Button8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button8.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button8.ForeColor = System.Drawing.Color.White;
            this.guna2Button8.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button8.HoverState.Parent = this.guna2Button8;
            this.guna2Button8.Image = global::viewminder1.Properties.Resources.ic_baseline_logout;
            this.guna2Button8.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button8.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button8.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button8.Location = new System.Drawing.Point(23, 381);
            this.guna2Button8.Name = "guna2Button8";
            this.guna2Button8.ShadowDecoration.Parent = this.guna2Button8;
            this.guna2Button8.Size = new System.Drawing.Size(199, 44);
            this.guna2Button8.TabIndex = 15;
            this.guna2Button8.Text = "Logout";
            this.guna2Button8.TextOffset = new System.Drawing.Point(-5, 0);
            this.guna2Button8.Click += new System.EventHandler(this.guna2Button8_Click);
            // 
            // guna2Button7
            // 
            this.guna2Button7.BorderRadius = 9;
            this.guna2Button7.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button7.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button7.CheckedState.Parent = this.guna2Button7;
            this.guna2Button7.CustomImages.Parent = this.guna2Button7;
            this.guna2Button7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button7.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button7.ForeColor = System.Drawing.Color.White;
            this.guna2Button7.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button7.HoverState.Parent = this.guna2Button7;
            this.guna2Button7.Image = global::viewminder1.Properties.Resources.ic_baseline_account_circle;
            this.guna2Button7.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button7.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button7.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button7.Location = new System.Drawing.Point(23, 331);
            this.guna2Button7.Name = "guna2Button7";
            this.guna2Button7.ShadowDecoration.Parent = this.guna2Button7;
            this.guna2Button7.Size = new System.Drawing.Size(199, 44);
            this.guna2Button7.TabIndex = 15;
            this.guna2Button7.Text = "Profile";
            this.guna2Button7.TextOffset = new System.Drawing.Point(-8, 0);
            this.guna2Button7.Click += new System.EventHandler(this.Guna2Button7_Click);
            // 
            // guna2Button2
            // 
            this.guna2Button2.BorderRadius = 9;
            this.guna2Button2.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.guna2Button2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button2.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.Image = global::viewminder1.Properties.Resources.ic_baseline_notifications;
            this.guna2Button2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button2.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button2.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button2.Location = new System.Drawing.Point(23, 281);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Size = new System.Drawing.Size(199, 44);
            this.guna2Button2.TabIndex = 15;
            this.guna2Button2.Text = "Notification";
            this.guna2Button2.TextOffset = new System.Drawing.Point(9, 0);
            this.guna2Button2.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // btnArchive
            // 
            this.btnArchive.BackColor = System.Drawing.Color.Transparent;
            this.btnArchive.BorderRadius = 9;
            this.btnArchive.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnArchive.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.btnArchive.CheckedState.ForeColor = System.Drawing.Color.White;
            this.btnArchive.CheckedState.Parent = this.btnArchive;
            this.btnArchive.CustomImages.Parent = this.btnArchive;
            this.btnArchive.FillColor = System.Drawing.Color.Transparent;
            this.btnArchive.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArchive.ForeColor = System.Drawing.Color.White;
            this.btnArchive.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.btnArchive.HoverState.Parent = this.btnArchive;
            this.btnArchive.Image = global::viewminder1.Properties.Resources.material_symbols_archive;
            this.btnArchive.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnArchive.ImageOffset = new System.Drawing.Point(16, 0);
            this.btnArchive.ImageSize = new System.Drawing.Size(16, 16);
            this.btnArchive.Location = new System.Drawing.Point(23, 231);
            this.btnArchive.Name = "btnArchive";
            this.btnArchive.ShadowDecoration.Parent = this.btnArchive;
            this.btnArchive.Size = new System.Drawing.Size(199, 44);
            this.btnArchive.TabIndex = 14;
            this.btnArchive.Text = "Archive";
            this.btnArchive.TextOffset = new System.Drawing.Point(-5, 0);
            this.btnArchive.Click += new System.EventHandler(this.Guna2Button1_Click_1);
            // 
            // btnSms
            // 
            this.btnSms.BorderRadius = 9;
            this.btnSms.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnSms.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.btnSms.CheckedState.Parent = this.btnSms;
            this.btnSms.CustomImages.Parent = this.btnSms;
            this.btnSms.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.btnSms.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSms.ForeColor = System.Drawing.Color.White;
            this.btnSms.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.btnSms.HoverState.Parent = this.btnSms;
            this.btnSms.Image = global::viewminder1.Properties.Resources.material_symbols_sms_sharp;
            this.btnSms.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnSms.ImageOffset = new System.Drawing.Point(16, 0);
            this.btnSms.ImageSize = new System.Drawing.Size(16, 16);
            this.btnSms.Location = new System.Drawing.Point(23, 181);
            this.btnSms.Name = "btnSms";
            this.btnSms.ShadowDecoration.Parent = this.btnSms;
            this.btnSms.Size = new System.Drawing.Size(199, 44);
            this.btnSms.TabIndex = 13;
            this.btnSms.Text = "Messages";
            this.btnSms.TextOffset = new System.Drawing.Point(3, 0);
            this.btnSms.Click += new System.EventHandler(this.guna2Button5_Click);
            // 
            // btnWatching
            // 
            this.btnWatching.BorderRadius = 9;
            this.btnWatching.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btnWatching.Checked = true;
            this.btnWatching.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.btnWatching.CheckedState.Parent = this.btnWatching;
            this.btnWatching.CustomImages.Parent = this.btnWatching;
            this.btnWatching.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.btnWatching.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWatching.ForeColor = System.Drawing.Color.White;
            this.btnWatching.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.btnWatching.HoverState.Parent = this.btnWatching;
            this.btnWatching.Image = global::viewminder1.Properties.Resources.carbon_view_filled;
            this.btnWatching.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnWatching.ImageOffset = new System.Drawing.Point(16, 0);
            this.btnWatching.ImageSize = new System.Drawing.Size(16, 16);
            this.btnWatching.Location = new System.Drawing.Point(23, 131);
            this.btnWatching.Name = "btnWatching";
            this.btnWatching.ShadowDecoration.Parent = this.btnWatching;
            this.btnWatching.Size = new System.Drawing.Size(199, 44);
            this.btnWatching.TabIndex = 9;
            this.btnWatching.Text = "Watching";
            this.btnWatching.Click += new System.EventHandler(this.BtnWatching_Click);
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(23, 98);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(95, 21);
            this.guna2HtmlLabel2.TabIndex = 4;
            this.guna2HtmlLabel2.Text = "MAIN MENU";
            this.guna2HtmlLabel2.Click += new System.EventHandler(this.Guna2HtmlLabel2_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = global::viewminder1.Properties.Resources.logo2;
            this.guna2PictureBox1.Location = new System.Drawing.Point(23, 17);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.ShadowDecoration.Parent = this.guna2PictureBox1;
            this.guna2PictureBox1.Size = new System.Drawing.Size(199, 64);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.guna2PictureBox1.TabIndex = 0;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.Click += new System.EventHandler(this.Guna2PictureBox1_Click);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 10;
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.BackColor = System.Drawing.Color.White;
            this.guna2Panel2.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Panel2.BorderRadius = 1;
            this.guna2Panel2.BorderThickness = 1;
            this.guna2Panel2.Controls.Add(this.guna2ControlBox3);
            this.guna2Panel2.Controls.Add(this.guna2ControlBox1);
            this.guna2Panel2.Controls.Add(this.guna2ControlBox2);
            this.guna2Panel2.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(56)))), ((int)(((byte)(56)))));
            this.guna2Panel2.CustomBorderThickness = new System.Windows.Forms.Padding(1, 0, 0, 0);
            this.guna2Panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel2.Location = new System.Drawing.Point(244, 0);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.ShadowDecoration.Parent = this.guna2Panel2;
            this.guna2Panel2.Size = new System.Drawing.Size(1229, 20);
            this.guna2Panel2.TabIndex = 1;
            this.guna2Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.Guna2Panel2_Paint);
            // 
            // guna2ControlBox3
            // 
            this.guna2ControlBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox3.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.guna2ControlBox3.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox3.HoverState.Parent = this.guna2ControlBox3;
            this.guna2ControlBox3.IconColor = System.Drawing.Color.Black;
            this.guna2ControlBox3.Location = new System.Drawing.Point(1130, 3);
            this.guna2ControlBox3.Name = "guna2ControlBox3";
            this.guna2ControlBox3.ShadowDecoration.Parent = this.guna2ControlBox3;
            this.guna2ControlBox3.Size = new System.Drawing.Size(25, 14);
            this.guna2ControlBox3.TabIndex = 7;
            this.guna2ControlBox3.Click += new System.EventHandler(this.Guna2ControlBox3_Click_2);
            // 
            // guna2ControlBox1
            // 
            this.guna2ControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox1.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MaximizeBox;
            this.guna2ControlBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.HoverState.Parent = this.guna2ControlBox1;
            this.guna2ControlBox1.IconColor = System.Drawing.Color.Black;
            this.guna2ControlBox1.Location = new System.Drawing.Point(1165, 3);
            this.guna2ControlBox1.Name = "guna2ControlBox1";
            this.guna2ControlBox1.ShadowDecoration.Parent = this.guna2ControlBox1;
            this.guna2ControlBox1.Size = new System.Drawing.Size(25, 14);
            this.guna2ControlBox1.TabIndex = 6;
            // 
            // guna2ControlBox2
            // 
            this.guna2ControlBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox2.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox2.HoverState.Parent = this.guna2ControlBox2;
            this.guna2ControlBox2.IconColor = System.Drawing.Color.Black;
            this.guna2ControlBox2.Location = new System.Drawing.Point(1197, 3);
            this.guna2ControlBox2.Name = "guna2ControlBox2";
            this.guna2ControlBox2.ShadowDecoration.Parent = this.guna2ControlBox2;
            this.guna2ControlBox2.Size = new System.Drawing.Size(25, 14);
            this.guna2ControlBox2.TabIndex = 5;
            this.guna2ControlBox2.Click += new System.EventHandler(this.guna2ControlBox2_Click_2);
            // 
            // guna2DragControl1
            // 
            this.guna2DragControl1.TargetControl = this;
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Aileron SemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(269, 122);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(3, 2);
            this.guna2HtmlLabel3.TabIndex = 5;
            this.guna2HtmlLabel3.Text = null;
            this.guna2HtmlLabel3.Click += new System.EventHandler(this.guna2HtmlLabel3_Click);
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel3.BackColor = System.Drawing.Color.White;
            this.guna2Panel3.BorderRadius = 9;
            this.guna2Panel3.Controls.Add(this.guna2PictureBox4);
            this.guna2Panel3.Controls.Add(this.guna2PictureBox7);
            this.guna2Panel3.Controls.Add(this.guna2HtmlLabel4);
            this.guna2Panel3.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.ShadowDecoration.Parent = this.guna2Panel3;
            this.guna2Panel3.Size = new System.Drawing.Size(1227, 51);
            this.guna2Panel3.TabIndex = 16;
            // 
            // guna2PictureBox4
            // 
            this.guna2PictureBox4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.guna2PictureBox4.Image = global::viewminder1.Properties.Resources.notifications;
            this.guna2PictureBox4.Location = new System.Drawing.Point(1131, 12);
            this.guna2PictureBox4.Name = "guna2PictureBox4";
            this.guna2PictureBox4.ShadowDecoration.Parent = this.guna2PictureBox4;
            this.guna2PictureBox4.Size = new System.Drawing.Size(24, 24);
            this.guna2PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox4.TabIndex = 6;
            this.guna2PictureBox4.TabStop = false;
            // 
            // guna2PictureBox7
            // 
            this.guna2PictureBox7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.guna2PictureBox7.Image = global::viewminder1.Properties.Resources.profile;
            this.guna2PictureBox7.Location = new System.Drawing.Point(1173, 12);
            this.guna2PictureBox7.Name = "guna2PictureBox7";
            this.guna2PictureBox7.ShadowDecoration.Parent = this.guna2PictureBox7;
            this.guna2PictureBox7.Size = new System.Drawing.Size(24, 24);
            this.guna2PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox7.TabIndex = 5;
            this.guna2PictureBox7.TabStop = false;
            this.guna2PictureBox7.Click += new System.EventHandler(this.Guna2PictureBox7_Click);
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Aileron SemiBold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(25, 12);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(249, 31);
            this.guna2HtmlLabel4.TabIndex = 3;
            this.guna2HtmlLabel4.Text = "Welcome back Admin!";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(948, 111);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 18;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Location = new System.Drawing.Point(25, 49);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1172, 777);
            this.tabControl1.TabIndex = 19;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.TabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1164, 751);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Controls.Add(this.tabPage9);
            this.tabControl2.Location = new System.Drawing.Point(-4, 1);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1172, 786);
            this.tabControl2.TabIndex = 21;
            this.tabControl2.SelectedIndexChanged += new System.EventHandler(this.TabControl2_SelectedIndexChanged);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.guna2Panel6);
            this.tabPage6.Controls.Add(this.guna2Panel5);
            this.tabPage6.Controls.Add(this.guna2Panel4);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel14);
            this.tabPage6.Controls.Add(this.guna2Panel1);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel13);
            this.tabPage6.Controls.Add(this.monthCalendar2);
            this.tabPage6.Controls.Add(this.guna2PictureBox12);
            this.tabPage6.Controls.Add(this.guna2PictureBox13);
            this.tabPage6.Controls.Add(this.guna2PictureBox14);
            this.tabPage6.Controls.Add(this.guna2PictureBox15);
            this.tabPage6.Controls.Add(this.guna2HtmlLabel8);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1164, 760);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "tabPage6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // guna2Panel6
            // 
            this.guna2Panel6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guna2Panel6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel6.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel6.BorderRadius = 8;
            this.guna2Panel6.BorderThickness = 1;
            this.guna2Panel6.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel6.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel6.Location = new System.Drawing.Point(899, 267);
            this.guna2Panel6.Name = "guna2Panel6";
            this.guna2Panel6.ShadowDecoration.Parent = this.guna2Panel6;
            this.guna2Panel6.Size = new System.Drawing.Size(227, 446);
            this.guna2Panel6.TabIndex = 35;
            // 
            // guna2Panel5
            // 
            this.guna2Panel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel5.BackgroundImage = global::viewminder1.Properties.Resources.Group_26092561;
            this.guna2Panel5.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel5.BorderThickness = 1;
            this.guna2Panel5.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel5.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.guna2Panel5.Location = new System.Drawing.Point(26, 67);
            this.guna2Panel5.Name = "guna2Panel5";
            this.guna2Panel5.ShadowDecoration.Parent = this.guna2Panel5;
            this.guna2Panel5.Size = new System.Drawing.Size(842, 395);
            this.guna2Panel5.TabIndex = 34;
            // 
            // guna2Panel4
            // 
            this.guna2Panel4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel4.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel4.BorderRadius = 8;
            this.guna2Panel4.BorderThickness = 1;
            this.guna2Panel4.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel4.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel4.Location = new System.Drawing.Point(463, 515);
            this.guna2Panel4.Name = "guna2Panel4";
            this.guna2Panel4.ShadowDecoration.Parent = this.guna2Panel4;
            this.guna2Panel4.Size = new System.Drawing.Size(405, 198);
            this.guna2Panel4.TabIndex = 33;
            // 
            // guna2HtmlLabel14
            // 
            this.guna2HtmlLabel14.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel14.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel14.Location = new System.Drawing.Point(463, 482);
            this.guna2HtmlLabel14.Name = "guna2HtmlLabel14";
            this.guna2HtmlLabel14.Size = new System.Drawing.Size(102, 27);
            this.guna2HtmlLabel14.TabIndex = 32;
            this.guna2HtmlLabel14.Text = "Messages";
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.DimGray;
            this.guna2Panel1.BackgroundImage = global::viewminder1.Properties.Resources.Rectangle_2419__1_2;
            this.guna2Panel1.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel1.BorderRadius = 8;
            this.guna2Panel1.BorderThickness = 1;
            this.guna2Panel1.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel1.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel1.Location = new System.Drawing.Point(26, 515);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(399, 198);
            this.guna2Panel1.TabIndex = 31;
            // 
            // guna2HtmlLabel13
            // 
            this.guna2HtmlLabel13.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel13.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel13.Location = new System.Drawing.Point(26, 482);
            this.guna2HtmlLabel13.Name = "guna2HtmlLabel13";
            this.guna2HtmlLabel13.Size = new System.Drawing.Size(135, 27);
            this.guna2HtmlLabel13.TabIndex = 29;
            this.guna2HtmlLabel13.Text = "Google Maps";
            // 
            // monthCalendar2
            // 
            this.monthCalendar2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.monthCalendar2.Location = new System.Drawing.Point(899, 67);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.TabIndex = 27;
            // 
            // guna2PictureBox12
            // 
            this.guna2PictureBox12.Image = global::viewminder1.Properties.Resources.cam4;
            this.guna2PictureBox12.Location = new System.Drawing.Point(245, 28);
            this.guna2PictureBox12.Name = "guna2PictureBox12";
            this.guna2PictureBox12.ShadowDecoration.Parent = this.guna2PictureBox12;
            this.guna2PictureBox12.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox12.TabIndex = 24;
            this.guna2PictureBox12.TabStop = false;
            this.guna2PictureBox12.Click += new System.EventHandler(this.Guna2PictureBox12_Click);
            // 
            // guna2PictureBox13
            // 
            this.guna2PictureBox13.Image = global::viewminder1.Properties.Resources.cam3;
            this.guna2PictureBox13.Location = new System.Drawing.Point(210, 28);
            this.guna2PictureBox13.Name = "guna2PictureBox13";
            this.guna2PictureBox13.ShadowDecoration.Parent = this.guna2PictureBox13;
            this.guna2PictureBox13.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox13.TabIndex = 23;
            this.guna2PictureBox13.TabStop = false;
            this.guna2PictureBox13.Click += new System.EventHandler(this.Guna2PictureBox13_Click);
            // 
            // guna2PictureBox14
            // 
            this.guna2PictureBox14.Image = global::viewminder1.Properties.Resources.cam2;
            this.guna2PictureBox14.Location = new System.Drawing.Point(173, 28);
            this.guna2PictureBox14.Name = "guna2PictureBox14";
            this.guna2PictureBox14.ShadowDecoration.Parent = this.guna2PictureBox14;
            this.guna2PictureBox14.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox14.TabIndex = 22;
            this.guna2PictureBox14.TabStop = false;
            this.guna2PictureBox14.Click += new System.EventHandler(this.Guna2PictureBox14_Click);
            // 
            // guna2PictureBox15
            // 
            this.guna2PictureBox15.Image = global::viewminder1.Properties.Resources.cam1;
            this.guna2PictureBox15.Location = new System.Drawing.Point(139, 28);
            this.guna2PictureBox15.Name = "guna2PictureBox15";
            this.guna2PictureBox15.ShadowDecoration.Parent = this.guna2PictureBox15;
            this.guna2PictureBox15.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox15.TabIndex = 21;
            this.guna2PictureBox15.TabStop = false;
            this.guna2PictureBox15.Click += new System.EventHandler(this.Guna2PictureBox15_Click);
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(26, 22);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(81, 27);
            this.guna2HtmlLabel8.TabIndex = 20;
            this.guna2HtmlLabel8.Text = "Camera";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.guna2Panel17);
            this.tabPage7.Controls.Add(this.guna2Panel15);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel23);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel24);
            this.tabPage7.Controls.Add(this.guna2HtmlLabel5);
            this.tabPage7.Controls.Add(this.guna2Panel16);
            this.tabPage7.Controls.Add(this.guna2Panel14);
            this.tabPage7.Controls.Add(this.guna2Panel10);
            this.tabPage7.Controls.Add(this.guna2PictureBox2);
            this.tabPage7.Controls.Add(this.guna2PictureBox3);
            this.tabPage7.Controls.Add(this.guna2PictureBox5);
            this.tabPage7.Controls.Add(this.guna2PictureBox6);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1164, 760);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "tabPage7";
            this.tabPage7.UseVisualStyleBackColor = true;
            this.tabPage7.Click += new System.EventHandler(this.TabPage7_Click);
            // 
            // guna2Panel17
            // 
            this.guna2Panel17.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel17.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel17.BorderRadius = 8;
            this.guna2Panel17.BorderThickness = 1;
            this.guna2Panel17.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel17.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel17.Location = new System.Drawing.Point(890, 513);
            this.guna2Panel17.Name = "guna2Panel17";
            this.guna2Panel17.ShadowDecoration.Parent = this.guna2Panel17;
            this.guna2Panel17.Size = new System.Drawing.Size(243, 198);
            this.guna2Panel17.TabIndex = 41;
            this.guna2Panel17.Paint += new System.Windows.Forms.PaintEventHandler(this.Guna2Panel17_Paint);
            // 
            // guna2Panel15
            // 
            this.guna2Panel15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel15.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel15.BorderRadius = 8;
            this.guna2Panel15.BorderThickness = 1;
            this.guna2Panel15.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel15.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel15.Location = new System.Drawing.Point(463, 513);
            this.guna2Panel15.Name = "guna2Panel15";
            this.guna2Panel15.ShadowDecoration.Parent = this.guna2Panel15;
            this.guna2Panel15.Size = new System.Drawing.Size(405, 198);
            this.guna2Panel15.TabIndex = 40;
            this.guna2Panel15.Paint += new System.Windows.Forms.PaintEventHandler(this.Guna2Panel15_Paint);
            // 
            // guna2HtmlLabel23
            // 
            this.guna2HtmlLabel23.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel23.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel23.Location = new System.Drawing.Point(463, 480);
            this.guna2HtmlLabel23.Name = "guna2HtmlLabel23";
            this.guna2HtmlLabel23.Size = new System.Drawing.Size(102, 27);
            this.guna2HtmlLabel23.TabIndex = 39;
            this.guna2HtmlLabel23.Text = "Messages";
            this.guna2HtmlLabel23.Click += new System.EventHandler(this.Guna2HtmlLabel23_Click);
            // 
            // guna2HtmlLabel24
            // 
            this.guna2HtmlLabel24.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel24.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel24.Location = new System.Drawing.Point(26, 480);
            this.guna2HtmlLabel24.Name = "guna2HtmlLabel24";
            this.guna2HtmlLabel24.Size = new System.Drawing.Size(135, 27);
            this.guna2HtmlLabel24.TabIndex = 37;
            this.guna2HtmlLabel24.Text = "Google Maps";
            this.guna2HtmlLabel24.Click += new System.EventHandler(this.Guna2HtmlLabel24_Click);
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(26, 22);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(81, 27);
            this.guna2HtmlLabel5.TabIndex = 28;
            this.guna2HtmlLabel5.Text = "Camera";
            // 
            // guna2Panel16
            // 
            this.guna2Panel16.BackColor = System.Drawing.Color.DimGray;
            this.guna2Panel16.BackgroundImage = global::viewminder1.Properties.Resources.Rectangle_2419__1_2;
            this.guna2Panel16.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel16.BorderRadius = 8;
            this.guna2Panel16.BorderThickness = 1;
            this.guna2Panel16.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel16.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel16.Location = new System.Drawing.Point(26, 513);
            this.guna2Panel16.Name = "guna2Panel16";
            this.guna2Panel16.ShadowDecoration.Parent = this.guna2Panel16;
            this.guna2Panel16.Size = new System.Drawing.Size(399, 198);
            this.guna2Panel16.TabIndex = 38;
            this.guna2Panel16.Paint += new System.Windows.Forms.PaintEventHandler(this.Guna2Panel16_Paint);
            // 
            // guna2Panel14
            // 
            this.guna2Panel14.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel14.BackgroundImage = global::viewminder1.Properties.Resources.Group_2609256;
            this.guna2Panel14.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel14.BorderRadius = 8;
            this.guna2Panel14.BorderThickness = 1;
            this.guna2Panel14.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel14.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel14.Location = new System.Drawing.Point(890, 67);
            this.guna2Panel14.Name = "guna2Panel14";
            this.guna2Panel14.ShadowDecoration.Parent = this.guna2Panel14;
            this.guna2Panel14.Size = new System.Drawing.Size(243, 395);
            this.guna2Panel14.TabIndex = 36;
            this.guna2Panel14.Paint += new System.Windows.Forms.PaintEventHandler(this.Guna2Panel14_Paint);
            // 
            // guna2Panel10
            // 
            this.guna2Panel10.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel10.BackgroundImage = global::viewminder1.Properties.Resources.Group_26092561;
            this.guna2Panel10.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Panel10.BorderRadius = 13;
            this.guna2Panel10.BorderThickness = 1;
            this.guna2Panel10.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel10.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.guna2Panel10.Location = new System.Drawing.Point(26, 67);
            this.guna2Panel10.Name = "guna2Panel10";
            this.guna2Panel10.ShadowDecoration.Parent = this.guna2Panel10;
            this.guna2Panel10.Size = new System.Drawing.Size(842, 395);
            this.guna2Panel10.TabIndex = 35;
            this.guna2Panel10.Paint += new System.Windows.Forms.PaintEventHandler(this.Guna2Panel10_Paint);
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.Image = global::viewminder1.Properties.Resources.cam4;
            this.guna2PictureBox2.Location = new System.Drawing.Point(245, 28);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.ShadowDecoration.Parent = this.guna2PictureBox2;
            this.guna2PictureBox2.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox2.TabIndex = 32;
            this.guna2PictureBox2.TabStop = false;
            this.guna2PictureBox2.Click += new System.EventHandler(this.Guna2PictureBox2_Click);
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.Image = global::viewminder1.Properties.Resources.cam3;
            this.guna2PictureBox3.Location = new System.Drawing.Point(210, 28);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.ShadowDecoration.Parent = this.guna2PictureBox3;
            this.guna2PictureBox3.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox3.TabIndex = 31;
            this.guna2PictureBox3.TabStop = false;
            this.guna2PictureBox3.Click += new System.EventHandler(this.Guna2PictureBox3_Click_1);
            // 
            // guna2PictureBox5
            // 
            this.guna2PictureBox5.Image = global::viewminder1.Properties.Resources.cam2;
            this.guna2PictureBox5.Location = new System.Drawing.Point(173, 28);
            this.guna2PictureBox5.Name = "guna2PictureBox5";
            this.guna2PictureBox5.ShadowDecoration.Parent = this.guna2PictureBox5;
            this.guna2PictureBox5.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox5.TabIndex = 30;
            this.guna2PictureBox5.TabStop = false;
            this.guna2PictureBox5.Click += new System.EventHandler(this.Guna2PictureBox5_Click);
            // 
            // guna2PictureBox6
            // 
            this.guna2PictureBox6.Image = global::viewminder1.Properties.Resources.cam1;
            this.guna2PictureBox6.Location = new System.Drawing.Point(139, 28);
            this.guna2PictureBox6.Name = "guna2PictureBox6";
            this.guna2PictureBox6.ShadowDecoration.Parent = this.guna2PictureBox6;
            this.guna2PictureBox6.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox6.TabIndex = 29;
            this.guna2PictureBox6.TabStop = false;
            this.guna2PictureBox6.Click += new System.EventHandler(this.Guna2PictureBox6_Click);
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.guna2Panel18);
            this.tabPage8.Controls.Add(this.guna2Panel19);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel25);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel26);
            this.tabPage8.Controls.Add(this.guna2HtmlLabel9);
            this.tabPage8.Controls.Add(this.guna2Panel20);
            this.tabPage8.Controls.Add(this.guna2Panel21);
            this.tabPage8.Controls.Add(this.guna2Panel22);
            this.tabPage8.Controls.Add(this.guna2PictureBox8);
            this.tabPage8.Controls.Add(this.guna2PictureBox9);
            this.tabPage8.Controls.Add(this.guna2PictureBox10);
            this.tabPage8.Controls.Add(this.guna2PictureBox11);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(1164, 760);
            this.tabPage8.TabIndex = 2;
            this.tabPage8.Text = "tabPage8";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // guna2Panel18
            // 
            this.guna2Panel18.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel18.BackgroundImage = global::viewminder1.Properties.Resources.Group_2609256;
            this.guna2Panel18.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel18.BorderRadius = 8;
            this.guna2Panel18.BorderThickness = 1;
            this.guna2Panel18.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel18.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel18.Location = new System.Drawing.Point(893, 504);
            this.guna2Panel18.Name = "guna2Panel18";
            this.guna2Panel18.ShadowDecoration.Parent = this.guna2Panel18;
            this.guna2Panel18.Size = new System.Drawing.Size(243, 198);
            this.guna2Panel18.TabIndex = 48;
            // 
            // guna2Panel19
            // 
            this.guna2Panel19.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel19.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel19.BorderRadius = 8;
            this.guna2Panel19.BorderThickness = 1;
            this.guna2Panel19.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel19.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel19.Location = new System.Drawing.Point(466, 504);
            this.guna2Panel19.Name = "guna2Panel19";
            this.guna2Panel19.ShadowDecoration.Parent = this.guna2Panel19;
            this.guna2Panel19.Size = new System.Drawing.Size(405, 198);
            this.guna2Panel19.TabIndex = 47;
            // 
            // guna2HtmlLabel25
            // 
            this.guna2HtmlLabel25.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel25.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel25.Location = new System.Drawing.Point(466, 471);
            this.guna2HtmlLabel25.Name = "guna2HtmlLabel25";
            this.guna2HtmlLabel25.Size = new System.Drawing.Size(102, 27);
            this.guna2HtmlLabel25.TabIndex = 46;
            this.guna2HtmlLabel25.Text = "Messages";
            // 
            // guna2HtmlLabel26
            // 
            this.guna2HtmlLabel26.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel26.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel26.Location = new System.Drawing.Point(29, 471);
            this.guna2HtmlLabel26.Name = "guna2HtmlLabel26";
            this.guna2HtmlLabel26.Size = new System.Drawing.Size(135, 27);
            this.guna2HtmlLabel26.TabIndex = 44;
            this.guna2HtmlLabel26.Text = "Google Maps";
            // 
            // guna2HtmlLabel9
            // 
            this.guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel9.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel9.Location = new System.Drawing.Point(28, 19);
            this.guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            this.guna2HtmlLabel9.Size = new System.Drawing.Size(81, 27);
            this.guna2HtmlLabel9.TabIndex = 25;
            this.guna2HtmlLabel9.Text = "Camera";
            // 
            // guna2Panel20
            // 
            this.guna2Panel20.BackColor = System.Drawing.Color.DimGray;
            this.guna2Panel20.BackgroundImage = global::viewminder1.Properties.Resources.Rectangle_2419__1_2;
            this.guna2Panel20.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel20.BorderRadius = 8;
            this.guna2Panel20.BorderThickness = 1;
            this.guna2Panel20.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel20.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel20.Location = new System.Drawing.Point(29, 504);
            this.guna2Panel20.Name = "guna2Panel20";
            this.guna2Panel20.ShadowDecoration.Parent = this.guna2Panel20;
            this.guna2Panel20.Size = new System.Drawing.Size(399, 198);
            this.guna2Panel20.TabIndex = 45;
            // 
            // guna2Panel21
            // 
            this.guna2Panel21.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel21.BackgroundImage = global::viewminder1.Properties.Resources.Group_2609256;
            this.guna2Panel21.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel21.BorderRadius = 8;
            this.guna2Panel21.BorderThickness = 1;
            this.guna2Panel21.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel21.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel21.Location = new System.Drawing.Point(893, 58);
            this.guna2Panel21.Name = "guna2Panel21";
            this.guna2Panel21.ShadowDecoration.Parent = this.guna2Panel21;
            this.guna2Panel21.Size = new System.Drawing.Size(243, 395);
            this.guna2Panel21.TabIndex = 43;
            // 
            // guna2Panel22
            // 
            this.guna2Panel22.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel22.BackgroundImage = global::viewminder1.Properties.Resources.Group_26092561;
            this.guna2Panel22.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Panel22.BorderRadius = 13;
            this.guna2Panel22.BorderThickness = 1;
            this.guna2Panel22.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel22.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel22.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.guna2Panel22.Location = new System.Drawing.Point(29, 58);
            this.guna2Panel22.Name = "guna2Panel22";
            this.guna2Panel22.ShadowDecoration.Parent = this.guna2Panel22;
            this.guna2Panel22.Size = new System.Drawing.Size(842, 395);
            this.guna2Panel22.TabIndex = 42;
            // 
            // guna2PictureBox8
            // 
            this.guna2PictureBox8.Image = global::viewminder1.Properties.Resources.cam4;
            this.guna2PictureBox8.Location = new System.Drawing.Point(248, 25);
            this.guna2PictureBox8.Name = "guna2PictureBox8";
            this.guna2PictureBox8.ShadowDecoration.Parent = this.guna2PictureBox8;
            this.guna2PictureBox8.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox8.TabIndex = 29;
            this.guna2PictureBox8.TabStop = false;
            this.guna2PictureBox8.Click += new System.EventHandler(this.Guna2PictureBox8_Click_1);
            // 
            // guna2PictureBox9
            // 
            this.guna2PictureBox9.Image = global::viewminder1.Properties.Resources.cam3;
            this.guna2PictureBox9.Location = new System.Drawing.Point(213, 25);
            this.guna2PictureBox9.Name = "guna2PictureBox9";
            this.guna2PictureBox9.ShadowDecoration.Parent = this.guna2PictureBox9;
            this.guna2PictureBox9.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox9.TabIndex = 28;
            this.guna2PictureBox9.TabStop = false;
            this.guna2PictureBox9.Click += new System.EventHandler(this.Guna2PictureBox9_Click_1);
            // 
            // guna2PictureBox10
            // 
            this.guna2PictureBox10.Image = global::viewminder1.Properties.Resources.cam2;
            this.guna2PictureBox10.Location = new System.Drawing.Point(176, 25);
            this.guna2PictureBox10.Name = "guna2PictureBox10";
            this.guna2PictureBox10.ShadowDecoration.Parent = this.guna2PictureBox10;
            this.guna2PictureBox10.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox10.TabIndex = 27;
            this.guna2PictureBox10.TabStop = false;
            this.guna2PictureBox10.Click += new System.EventHandler(this.Guna2PictureBox10_Click_1);
            // 
            // guna2PictureBox11
            // 
            this.guna2PictureBox11.Image = global::viewminder1.Properties.Resources.cam1;
            this.guna2PictureBox11.Location = new System.Drawing.Point(142, 25);
            this.guna2PictureBox11.Name = "guna2PictureBox11";
            this.guna2PictureBox11.ShadowDecoration.Parent = this.guna2PictureBox11;
            this.guna2PictureBox11.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox11.TabIndex = 26;
            this.guna2PictureBox11.TabStop = false;
            this.guna2PictureBox11.Click += new System.EventHandler(this.Guna2PictureBox11_Click_1);
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.guna2Panel23);
            this.tabPage9.Controls.Add(this.guna2Panel24);
            this.tabPage9.Controls.Add(this.guna2HtmlLabel28);
            this.tabPage9.Controls.Add(this.guna2HtmlLabel10);
            this.tabPage9.Controls.Add(this.guna2Panel26);
            this.tabPage9.Controls.Add(this.guna2Panel27);
            this.tabPage9.Controls.Add(this.guna2PictureBox16);
            this.tabPage9.Controls.Add(this.guna2PictureBox17);
            this.tabPage9.Controls.Add(this.guna2PictureBox18);
            this.tabPage9.Controls.Add(this.guna2PictureBox19);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(1164, 760);
            this.tabPage9.TabIndex = 3;
            this.tabPage9.Text = "tabPage9";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // guna2Panel23
            // 
            this.guna2Panel23.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel23.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel23.BorderRadius = 8;
            this.guna2Panel23.BorderThickness = 1;
            this.guna2Panel23.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel23.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel23.Location = new System.Drawing.Point(611, 504);
            this.guna2Panel23.Name = "guna2Panel23";
            this.guna2Panel23.ShadowDecoration.Parent = this.guna2Panel23;
            this.guna2Panel23.Size = new System.Drawing.Size(525, 198);
            this.guna2Panel23.TabIndex = 48;
            // 
            // guna2Panel24
            // 
            this.guna2Panel24.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel24.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel24.BorderRadius = 8;
            this.guna2Panel24.BorderThickness = 1;
            this.guna2Panel24.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel24.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel24.Location = new System.Drawing.Point(29, 504);
            this.guna2Panel24.Name = "guna2Panel24";
            this.guna2Panel24.ShadowDecoration.Parent = this.guna2Panel24;
            this.guna2Panel24.Size = new System.Drawing.Size(551, 198);
            this.guna2Panel24.TabIndex = 47;
            // 
            // guna2HtmlLabel28
            // 
            this.guna2HtmlLabel28.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel28.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel28.Location = new System.Drawing.Point(29, 471);
            this.guna2HtmlLabel28.Name = "guna2HtmlLabel28";
            this.guna2HtmlLabel28.Size = new System.Drawing.Size(98, 27);
            this.guna2HtmlLabel28.TabIndex = 44;
            this.guna2HtmlLabel28.Text = "Camera 4";
            // 
            // guna2HtmlLabel10
            // 
            this.guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel10.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel10.Location = new System.Drawing.Point(25, 22);
            this.guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            this.guna2HtmlLabel10.Size = new System.Drawing.Size(81, 27);
            this.guna2HtmlLabel10.TabIndex = 25;
            this.guna2HtmlLabel10.Text = "Camera";
            // 
            // guna2Panel26
            // 
            this.guna2Panel26.BackColor = System.Drawing.Color.WhiteSmoke;
            this.guna2Panel26.BackgroundImage = global::viewminder1.Properties.Resources.Group_2609256;
            this.guna2Panel26.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel26.BorderRadius = 8;
            this.guna2Panel26.BorderThickness = 1;
            this.guna2Panel26.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel26.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel26.Location = new System.Drawing.Point(611, 58);
            this.guna2Panel26.Name = "guna2Panel26";
            this.guna2Panel26.ShadowDecoration.Parent = this.guna2Panel26;
            this.guna2Panel26.Size = new System.Drawing.Size(525, 395);
            this.guna2Panel26.TabIndex = 43;
            // 
            // guna2Panel27
            // 
            this.guna2Panel27.BackColor = System.Drawing.Color.Transparent;
            this.guna2Panel27.BackgroundImage = global::viewminder1.Properties.Resources.Group_26092561;
            this.guna2Panel27.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Panel27.BorderRadius = 13;
            this.guna2Panel27.BorderThickness = 1;
            this.guna2Panel27.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel27.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel27.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.guna2Panel27.Location = new System.Drawing.Point(29, 58);
            this.guna2Panel27.Name = "guna2Panel27";
            this.guna2Panel27.ShadowDecoration.Parent = this.guna2Panel27;
            this.guna2Panel27.Size = new System.Drawing.Size(551, 395);
            this.guna2Panel27.TabIndex = 42;
            // 
            // guna2PictureBox16
            // 
            this.guna2PictureBox16.Image = global::viewminder1.Properties.Resources.cam4;
            this.guna2PictureBox16.Location = new System.Drawing.Point(244, 28);
            this.guna2PictureBox16.Name = "guna2PictureBox16";
            this.guna2PictureBox16.ShadowDecoration.Parent = this.guna2PictureBox16;
            this.guna2PictureBox16.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox16.TabIndex = 29;
            this.guna2PictureBox16.TabStop = false;
            this.guna2PictureBox16.Click += new System.EventHandler(this.Guna2PictureBox16_Click);
            // 
            // guna2PictureBox17
            // 
            this.guna2PictureBox17.Image = global::viewminder1.Properties.Resources.cam3;
            this.guna2PictureBox17.Location = new System.Drawing.Point(209, 28);
            this.guna2PictureBox17.Name = "guna2PictureBox17";
            this.guna2PictureBox17.ShadowDecoration.Parent = this.guna2PictureBox17;
            this.guna2PictureBox17.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox17.TabIndex = 28;
            this.guna2PictureBox17.TabStop = false;
            this.guna2PictureBox17.Click += new System.EventHandler(this.Guna2PictureBox17_Click);
            // 
            // guna2PictureBox18
            // 
            this.guna2PictureBox18.Image = global::viewminder1.Properties.Resources.cam2;
            this.guna2PictureBox18.Location = new System.Drawing.Point(172, 28);
            this.guna2PictureBox18.Name = "guna2PictureBox18";
            this.guna2PictureBox18.ShadowDecoration.Parent = this.guna2PictureBox18;
            this.guna2PictureBox18.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox18.TabIndex = 27;
            this.guna2PictureBox18.TabStop = false;
            this.guna2PictureBox18.Click += new System.EventHandler(this.Guna2PictureBox18_Click);
            // 
            // guna2PictureBox19
            // 
            this.guna2PictureBox19.Image = global::viewminder1.Properties.Resources.cam1;
            this.guna2PictureBox19.Location = new System.Drawing.Point(138, 28);
            this.guna2PictureBox19.Name = "guna2PictureBox19";
            this.guna2PictureBox19.ShadowDecoration.Parent = this.guna2PictureBox19;
            this.guna2PictureBox19.Size = new System.Drawing.Size(16, 16);
            this.guna2PictureBox19.TabIndex = 26;
            this.guna2PictureBox19.TabStop = false;
            this.guna2PictureBox19.Click += new System.EventHandler(this.Guna2PictureBox19_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.guna2Button9);
            this.tabPage2.Controls.Add(this.guna2Button6);
            this.tabPage2.Controls.Add(this.guna2Panel7);
            this.tabPage2.Controls.Add(this.guna2Button5);
            this.tabPage2.Controls.Add(this.guna2HtmlLabel6);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1164, 751);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.TabPage2_Click);
            // 
            // guna2Button9
            // 
            this.guna2Button9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button9.BackColor = System.Drawing.Color.White;
            this.guna2Button9.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button9.BorderRadius = 9;
            this.guna2Button9.BorderThickness = 1;
            this.guna2Button9.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button9.CheckedState.Parent = this.guna2Button9;
            this.guna2Button9.CustomImages.Parent = this.guna2Button9;
            this.guna2Button9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button9.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button9.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button9.HoverState.Parent = this.guna2Button9;
            this.guna2Button9.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button9.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button9.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button9.Location = new System.Drawing.Point(1031, 40);
            this.guna2Button9.Name = "guna2Button9";
            this.guna2Button9.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button9.ShadowDecoration.Parent = this.guna2Button9;
            this.guna2Button9.Size = new System.Drawing.Size(95, 34);
            this.guna2Button9.TabIndex = 19;
            this.guna2Button9.Text = "Select all";
            // 
            // guna2Button6
            // 
            this.guna2Button6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button6.BackColor = System.Drawing.Color.White;
            this.guna2Button6.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button6.BorderRadius = 9;
            this.guna2Button6.BorderThickness = 1;
            this.guna2Button6.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button6.CheckedState.Parent = this.guna2Button6;
            this.guna2Button6.CustomImages.Parent = this.guna2Button6;
            this.guna2Button6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button6.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button6.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button6.HoverState.Parent = this.guna2Button6;
            this.guna2Button6.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button6.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button6.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button6.Location = new System.Drawing.Point(929, 40);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button6.ShadowDecoration.Parent = this.guna2Button6;
            this.guna2Button6.Size = new System.Drawing.Size(95, 34);
            this.guna2Button6.TabIndex = 18;
            this.guna2Button6.Text = "Cancel";
            // 
            // guna2Panel7
            // 
            this.guna2Panel7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel7.BackColor = System.Drawing.Color.White;
            this.guna2Panel7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(209)))), ((int)(((byte)(213)))));
            this.guna2Panel7.BorderRadius = 6;
            this.guna2Panel7.BorderThickness = 1;
            this.guna2Panel7.Controls.Add(this.guna2Panel11);
            this.guna2Panel7.Controls.Add(this.pictureBox15);
            this.guna2Panel7.Controls.Add(this.label12);
            this.guna2Panel7.Controls.Add(this.pictureBox16);
            this.guna2Panel7.Controls.Add(this.guna2Separator5);
            this.guna2Panel7.Controls.Add(this.label13);
            this.guna2Panel7.Controls.Add(this.label14);
            this.guna2Panel7.Controls.Add(this.pictureBox14);
            this.guna2Panel7.Controls.Add(this.label9);
            this.guna2Panel7.Controls.Add(this.pictureBox13);
            this.guna2Panel7.Controls.Add(this.guna2Separator4);
            this.guna2Panel7.Controls.Add(this.label10);
            this.guna2Panel7.Controls.Add(this.label11);
            this.guna2Panel7.Controls.Add(this.label5);
            this.guna2Panel7.Controls.Add(this.pictureBox11);
            this.guna2Panel7.Controls.Add(this.guna2Separator2);
            this.guna2Panel7.Controls.Add(this.label3);
            this.guna2Panel7.Controls.Add(this.label4);
            this.guna2Panel7.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(209)))), ((int)(((byte)(213)))));
            this.guna2Panel7.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel7.Location = new System.Drawing.Point(28, 90);
            this.guna2Panel7.Name = "guna2Panel7";
            this.guna2Panel7.ShadowDecoration.Parent = this.guna2Panel7;
            this.guna2Panel7.Size = new System.Drawing.Size(1098, 629);
            this.guna2Panel7.TabIndex = 17;
            // 
            // guna2Panel11
            // 
            this.guna2Panel11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(255)))), ((int)(((byte)(216)))));
            this.guna2Panel11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(197)))), ((int)(((byte)(153)))));
            this.guna2Panel11.BorderRadius = 15;
            this.guna2Panel11.BorderThickness = 1;
            this.guna2Panel11.Controls.Add(this.label16);
            this.guna2Panel11.Controls.Add(this.label15);
            this.guna2Panel11.Controls.Add(this.pictureBox17);
            this.guna2Panel11.Location = new System.Drawing.Point(650, 497);
            this.guna2Panel11.Name = "guna2Panel11";
            this.guna2Panel11.ShadowDecoration.Parent = this.guna2Panel11;
            this.guna2Panel11.Size = new System.Drawing.Size(415, 90);
            this.guna2Panel11.TabIndex = 21;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(149)))), ((int)(((byte)(14)))));
            this.label16.Location = new System.Drawing.Point(22, 52);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(327, 19);
            this.label16.TabIndex = 17;
            this.label16.Text = "The changes has been saved to the database.";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(149)))), ((int)(((byte)(14)))));
            this.label15.Location = new System.Drawing.Point(22, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(326, 19);
            this.label15.TabIndex = 10;
            this.label15.Text = "Messages has been removed successfully.";
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::viewminder1.Properties.Resources.Vector;
            this.pictureBox17.Location = new System.Drawing.Point(374, 12);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(28, 28);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox17.TabIndex = 8;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::viewminder1.Properties.Resources.carbon_checkbox;
            this.pictureBox15.Location = new System.Drawing.Point(17, 98);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(28, 28);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox15.TabIndex = 20;
            this.pictureBox15.TabStop = false;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label12.Location = new System.Drawing.Point(1018, 102);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 19);
            this.label12.TabIndex = 19;
            this.label12.Text = "5:14 PM";
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::viewminder1.Properties.Resources.ic_round_warning;
            this.pictureBox16.Location = new System.Drawing.Point(57, 98);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(28, 28);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox16.TabIndex = 18;
            this.pictureBox16.TabStop = false;
            // 
            // guna2Separator5
            // 
            this.guna2Separator5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator5.Location = new System.Drawing.Point(3, 129);
            this.guna2Separator5.Name = "guna2Separator5";
            this.guna2Separator5.Size = new System.Drawing.Size(1092, 10);
            this.guna2Separator5.TabIndex = 17;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(228, 102);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(426, 19);
            this.label13.TabIndex = 16;
            this.label13.Text = "- Cam 1 | Room 3 : Motion detected at 2023-08-14 | 5: 14 PM ";
            this.label13.Click += new System.EventHandler(this.Label13_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(91, 102);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(142, 19);
            this.label14.TabIndex = 15;
            this.label14.Text = "Motion detection ";
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::viewminder1.Properties.Resources.ion_checkbox;
            this.pictureBox14.Location = new System.Drawing.Point(17, 54);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(28, 28);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox14.TabIndex = 14;
            this.pictureBox14.TabStop = false;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label9.Location = new System.Drawing.Point(1018, 58);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 19);
            this.label9.TabIndex = 13;
            this.label9.Text = "5:14 PM";
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::viewminder1.Properties.Resources.ic_round_warning;
            this.pictureBox13.Location = new System.Drawing.Point(57, 54);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(28, 28);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox13.TabIndex = 12;
            this.pictureBox13.TabStop = false;
            // 
            // guna2Separator4
            // 
            this.guna2Separator4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator4.Location = new System.Drawing.Point(3, 85);
            this.guna2Separator4.Name = "guna2Separator4";
            this.guna2Separator4.Size = new System.Drawing.Size(1092, 10);
            this.guna2Separator4.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(228, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(426, 19);
            this.label10.TabIndex = 10;
            this.label10.Text = "- Cam 1 | Room 3 : Motion detected at 2023-08-14 | 5: 14 PM ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(91, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(142, 19);
            this.label11.TabIndex = 9;
            this.label11.Text = "Motion detection ";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label5.Location = new System.Drawing.Point(1018, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 19);
            this.label5.TabIndex = 8;
            this.label5.Text = "5:14 PM";
            this.label5.Click += new System.EventHandler(this.Label5_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::viewminder1.Properties.Resources.ic_round_warning;
            this.pictureBox11.Location = new System.Drawing.Point(17, 8);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(28, 28);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox11.TabIndex = 7;
            this.pictureBox11.TabStop = false;
            // 
            // guna2Separator2
            // 
            this.guna2Separator2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator2.Location = new System.Drawing.Point(3, 39);
            this.guna2Separator2.Name = "guna2Separator2";
            this.guna2Separator2.Size = new System.Drawing.Size(1092, 10);
            this.guna2Separator2.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(188, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(426, 19);
            this.label3.TabIndex = 5;
            this.label3.Text = "- Cam 1 | Room 3 : Motion detected at 2023-08-14 | 5: 14 PM ";
            this.label3.Click += new System.EventHandler(this.Label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(51, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 19);
            this.label4.TabIndex = 4;
            this.label4.Text = "Motion detection ";
            // 
            // guna2Button5
            // 
            this.guna2Button5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button5.BackColor = System.Drawing.Color.White;
            this.guna2Button5.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button5.BorderRadius = 9;
            this.guna2Button5.BorderThickness = 1;
            this.guna2Button5.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button5.CheckedState.Parent = this.guna2Button5;
            this.guna2Button5.CustomImages.Parent = this.guna2Button5;
            this.guna2Button5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button5.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.guna2Button5.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button5.HoverState.Parent = this.guna2Button5;
            this.guna2Button5.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button5.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button5.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button5.Location = new System.Drawing.Point(828, 40);
            this.guna2Button5.Name = "guna2Button5";
            this.guna2Button5.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button5.ShadowDecoration.Parent = this.guna2Button5;
            this.guna2Button5.Size = new System.Drawing.Size(95, 34);
            this.guna2Button5.TabIndex = 16;
            this.guna2Button5.Text = "Delete";
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(28, 31);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(102, 27);
            this.guna2HtmlLabel6.TabIndex = 13;
            this.guna2HtmlLabel6.Text = "Messages";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.guna2Button1);
            this.tabPage3.Controls.Add(this.guna2Button10);
            this.tabPage3.Controls.Add(this.guna2Button11);
            this.tabPage3.Controls.Add(this.guna2Panel8);
            this.tabPage3.Controls.Add(this.guna2HtmlLabel7);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1164, 751);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Click += new System.EventHandler(this.TabPage3_Click);
            // 
            // guna2Button1
            // 
            this.guna2Button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button1.BackColor = System.Drawing.Color.White;
            this.guna2Button1.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button1.BorderRadius = 9;
            this.guna2Button1.BorderThickness = 1;
            this.guna2Button1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button1.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button1.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button1.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button1.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button1.Location = new System.Drawing.Point(1031, 40);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(95, 34);
            this.guna2Button1.TabIndex = 22;
            this.guna2Button1.Text = "Select all";
            this.guna2Button1.Click += new System.EventHandler(this.Guna2Button1_Click_3);
            // 
            // guna2Button10
            // 
            this.guna2Button10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button10.BackColor = System.Drawing.Color.White;
            this.guna2Button10.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button10.BorderRadius = 9;
            this.guna2Button10.BorderThickness = 1;
            this.guna2Button10.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button10.CheckedState.Parent = this.guna2Button10;
            this.guna2Button10.CustomImages.Parent = this.guna2Button10;
            this.guna2Button10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button10.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button10.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button10.HoverState.Parent = this.guna2Button10;
            this.guna2Button10.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button10.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button10.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button10.Location = new System.Drawing.Point(929, 40);
            this.guna2Button10.Name = "guna2Button10";
            this.guna2Button10.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button10.ShadowDecoration.Parent = this.guna2Button10;
            this.guna2Button10.Size = new System.Drawing.Size(95, 34);
            this.guna2Button10.TabIndex = 21;
            this.guna2Button10.Text = "Cancel";
            this.guna2Button10.Click += new System.EventHandler(this.Guna2Button10_Click);
            // 
            // guna2Button11
            // 
            this.guna2Button11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button11.BackColor = System.Drawing.Color.White;
            this.guna2Button11.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button11.BorderRadius = 9;
            this.guna2Button11.BorderThickness = 1;
            this.guna2Button11.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button11.CheckedState.Parent = this.guna2Button11;
            this.guna2Button11.CustomImages.Parent = this.guna2Button11;
            this.guna2Button11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button11.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.guna2Button11.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button11.HoverState.Parent = this.guna2Button11;
            this.guna2Button11.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button11.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button11.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button11.Location = new System.Drawing.Point(828, 40);
            this.guna2Button11.Name = "guna2Button11";
            this.guna2Button11.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button11.ShadowDecoration.Parent = this.guna2Button11;
            this.guna2Button11.Size = new System.Drawing.Size(95, 34);
            this.guna2Button11.TabIndex = 20;
            this.guna2Button11.Text = "Delete";
            this.guna2Button11.Click += new System.EventHandler(this.Guna2Button11_Click);
            // 
            // guna2Panel8
            // 
            this.guna2Panel8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel8.BackColor = System.Drawing.Color.White;
            this.guna2Panel8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(209)))), ((int)(((byte)(213)))));
            this.guna2Panel8.BorderRadius = 6;
            this.guna2Panel8.BorderThickness = 1;
            this.guna2Panel8.Controls.Add(this.guna2Panel12);
            this.guna2Panel8.Controls.Add(this.pictureBox20);
            this.guna2Panel8.Controls.Add(this.label20);
            this.guna2Panel8.Controls.Add(this.label21);
            this.guna2Panel8.Controls.Add(this.pictureBox21);
            this.guna2Panel8.Controls.Add(this.guna2Separator7);
            this.guna2Panel8.Controls.Add(this.label22);
            this.guna2Panel8.Controls.Add(this.pictureBox19);
            this.guna2Panel8.Controls.Add(this.label17);
            this.guna2Panel8.Controls.Add(this.label18);
            this.guna2Panel8.Controls.Add(this.pictureBox18);
            this.guna2Panel8.Controls.Add(this.guna2Separator6);
            this.guna2Panel8.Controls.Add(this.label19);
            this.guna2Panel8.Controls.Add(this.label6);
            this.guna2Panel8.Controls.Add(this.label8);
            this.guna2Panel8.Controls.Add(this.pictureBox12);
            this.guna2Panel8.Controls.Add(this.guna2Separator3);
            this.guna2Panel8.Controls.Add(this.label7);
            this.guna2Panel8.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(209)))), ((int)(((byte)(213)))));
            this.guna2Panel8.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel8.Location = new System.Drawing.Point(28, 90);
            this.guna2Panel8.Name = "guna2Panel8";
            this.guna2Panel8.ShadowDecoration.Parent = this.guna2Panel8;
            this.guna2Panel8.Size = new System.Drawing.Size(1098, 629);
            this.guna2Panel8.TabIndex = 18;
            this.guna2Panel8.Paint += new System.Windows.Forms.PaintEventHandler(this.Guna2Panel8_Paint);
            // 
            // guna2Panel12
            // 
            this.guna2Panel12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(255)))), ((int)(((byte)(216)))));
            this.guna2Panel12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(197)))), ((int)(((byte)(153)))));
            this.guna2Panel12.BorderRadius = 15;
            this.guna2Panel12.BorderThickness = 1;
            this.guna2Panel12.Controls.Add(this.label23);
            this.guna2Panel12.Controls.Add(this.label24);
            this.guna2Panel12.Controls.Add(this.pictureBox22);
            this.guna2Panel12.Location = new System.Drawing.Point(650, 497);
            this.guna2Panel12.Name = "guna2Panel12";
            this.guna2Panel12.ShadowDecoration.Parent = this.guna2Panel12;
            this.guna2Panel12.Size = new System.Drawing.Size(415, 90);
            this.guna2Panel12.TabIndex = 26;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(149)))), ((int)(((byte)(14)))));
            this.label23.Location = new System.Drawing.Point(22, 52);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(327, 19);
            this.label23.TabIndex = 17;
            this.label23.Text = "The changes has been saved to the database.";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(149)))), ((int)(((byte)(14)))));
            this.label24.Location = new System.Drawing.Point(22, 21);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(295, 19);
            this.label24.TabIndex = 10;
            this.label24.Text = "Video has been removed successfully.";
            this.label24.Click += new System.EventHandler(this.Label24_Click);
            // 
            // pictureBox22
            // 
            this.pictureBox22.Image = global::viewminder1.Properties.Resources.Vector;
            this.pictureBox22.Location = new System.Drawing.Point(374, 12);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(28, 28);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox22.TabIndex = 8;
            this.pictureBox22.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Image = global::viewminder1.Properties.Resources.carbon_checkbox;
            this.pictureBox20.Location = new System.Drawing.Point(17, 92);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(28, 28);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox20.TabIndex = 25;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Click += new System.EventHandler(this.PictureBox20_Click);
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label20.Location = new System.Drawing.Point(538, 96);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(120, 19);
            this.label20.TabIndex = 24;
            this.label20.Text = "August 20,2023";
            this.label20.Click += new System.EventHandler(this.Label20_Click);
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label21.Location = new System.Drawing.Point(1018, 96);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(67, 19);
            this.label21.TabIndex = 23;
            this.label21.Text = "5:14 PM";
            this.label21.Click += new System.EventHandler(this.Label21_Click);
            // 
            // pictureBox21
            // 
            this.pictureBox21.Image = global::viewminder1.Properties.Resources.mdi_folder_play;
            this.pictureBox21.Location = new System.Drawing.Point(60, 92);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(28, 28);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox21.TabIndex = 22;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Click += new System.EventHandler(this.PictureBox21_Click);
            // 
            // guna2Separator7
            // 
            this.guna2Separator7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator7.Location = new System.Drawing.Point(3, 123);
            this.guna2Separator7.Name = "guna2Separator7";
            this.guna2Separator7.Size = new System.Drawing.Size(1092, 10);
            this.guna2Separator7.TabIndex = 21;
            this.guna2Separator7.Click += new System.EventHandler(this.Guna2Separator7_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(94, 96);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(200, 19);
            this.label22.TabIndex = 20;
            this.label22.Text = " Recorded video 12345678";
            this.label22.Click += new System.EventHandler(this.Label22_Click);
            // 
            // pictureBox19
            // 
            this.pictureBox19.Image = global::viewminder1.Properties.Resources.ion_checkbox;
            this.pictureBox19.Location = new System.Drawing.Point(17, 50);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(28, 28);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox19.TabIndex = 19;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Click += new System.EventHandler(this.PictureBox19_Click);
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label17.Location = new System.Drawing.Point(538, 54);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(120, 19);
            this.label17.TabIndex = 18;
            this.label17.Text = "August 20,2023";
            this.label17.Click += new System.EventHandler(this.Label17_Click);
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label18.Location = new System.Drawing.Point(1018, 54);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 19);
            this.label18.TabIndex = 17;
            this.label18.Text = "5:14 PM";
            this.label18.Click += new System.EventHandler(this.Label18_Click);
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::viewminder1.Properties.Resources.mdi_folder_play;
            this.pictureBox18.Location = new System.Drawing.Point(60, 50);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(28, 28);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox18.TabIndex = 16;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Click += new System.EventHandler(this.PictureBox18_Click);
            // 
            // guna2Separator6
            // 
            this.guna2Separator6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator6.Location = new System.Drawing.Point(3, 81);
            this.guna2Separator6.Name = "guna2Separator6";
            this.guna2Separator6.Size = new System.Drawing.Size(1092, 10);
            this.guna2Separator6.TabIndex = 15;
            this.guna2Separator6.Click += new System.EventHandler(this.Guna2Separator6_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(94, 54);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(200, 19);
            this.label19.TabIndex = 14;
            this.label19.Text = " Recorded video 12345678";
            this.label19.Click += new System.EventHandler(this.Label19_Click);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label6.Location = new System.Drawing.Point(495, 12);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 19);
            this.label6.TabIndex = 13;
            this.label6.Text = "August 20,2023";
            this.label6.Click += new System.EventHandler(this.Label6_Click);
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label8.Location = new System.Drawing.Point(1018, 12);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 19);
            this.label8.TabIndex = 12;
            this.label8.Text = "5:14 PM";
            this.label8.Click += new System.EventHandler(this.Label8_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::viewminder1.Properties.Resources.mdi_folder_play;
            this.pictureBox12.Location = new System.Drawing.Point(17, 8);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(28, 28);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox12.TabIndex = 11;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.PictureBox12_Click);
            // 
            // guna2Separator3
            // 
            this.guna2Separator3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator3.Location = new System.Drawing.Point(3, 39);
            this.guna2Separator3.Name = "guna2Separator3";
            this.guna2Separator3.Size = new System.Drawing.Size(1092, 10);
            this.guna2Separator3.TabIndex = 10;
            this.guna2Separator3.Click += new System.EventHandler(this.Guna2Separator3_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(51, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(200, 19);
            this.label7.TabIndex = 8;
            this.label7.Text = " Recorded video 12345678";
            this.label7.Click += new System.EventHandler(this.Label7_Click);
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(28, 31);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(80, 27);
            this.guna2HtmlLabel7.TabIndex = 13;
            this.guna2HtmlLabel7.Text = "Archive";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.guna2Button3);
            this.tabPage4.Controls.Add(this.guna2Button12);
            this.tabPage4.Controls.Add(this.guna2Button13);
            this.tabPage4.Controls.Add(this.guna2Panel9);
            this.tabPage4.Controls.Add(this.guna2HtmlLabel11);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1164, 751);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // guna2Button3
            // 
            this.guna2Button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button3.BackColor = System.Drawing.Color.White;
            this.guna2Button3.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button3.BorderRadius = 9;
            this.guna2Button3.BorderThickness = 1;
            this.guna2Button3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button3.CheckedState.Parent = this.guna2Button3;
            this.guna2Button3.CustomImages.Parent = this.guna2Button3;
            this.guna2Button3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button3.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button3.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button3.HoverState.Parent = this.guna2Button3;
            this.guna2Button3.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button3.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button3.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button3.Location = new System.Drawing.Point(1031, 40);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button3.ShadowDecoration.Parent = this.guna2Button3;
            this.guna2Button3.Size = new System.Drawing.Size(95, 34);
            this.guna2Button3.TabIndex = 25;
            this.guna2Button3.Text = "Select all";
            // 
            // guna2Button12
            // 
            this.guna2Button12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button12.BackColor = System.Drawing.Color.White;
            this.guna2Button12.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button12.BorderRadius = 9;
            this.guna2Button12.BorderThickness = 1;
            this.guna2Button12.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button12.CheckedState.Parent = this.guna2Button12;
            this.guna2Button12.CustomImages.Parent = this.guna2Button12;
            this.guna2Button12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button12.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button12.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button12.HoverState.Parent = this.guna2Button12;
            this.guna2Button12.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button12.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button12.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button12.Location = new System.Drawing.Point(929, 40);
            this.guna2Button12.Name = "guna2Button12";
            this.guna2Button12.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button12.ShadowDecoration.Parent = this.guna2Button12;
            this.guna2Button12.Size = new System.Drawing.Size(95, 34);
            this.guna2Button12.TabIndex = 24;
            this.guna2Button12.Text = "Cancel";
            // 
            // guna2Button13
            // 
            this.guna2Button13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button13.BackColor = System.Drawing.Color.White;
            this.guna2Button13.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button13.BorderRadius = 9;
            this.guna2Button13.BorderThickness = 1;
            this.guna2Button13.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button13.CheckedState.Parent = this.guna2Button13;
            this.guna2Button13.CustomImages.Parent = this.guna2Button13;
            this.guna2Button13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button13.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.guna2Button13.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button13.HoverState.Parent = this.guna2Button13;
            this.guna2Button13.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button13.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button13.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button13.Location = new System.Drawing.Point(828, 40);
            this.guna2Button13.Name = "guna2Button13";
            this.guna2Button13.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button13.ShadowDecoration.Parent = this.guna2Button13;
            this.guna2Button13.Size = new System.Drawing.Size(95, 34);
            this.guna2Button13.TabIndex = 23;
            this.guna2Button13.Text = "Delete";
            // 
            // guna2Panel9
            // 
            this.guna2Panel9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel9.BackColor = System.Drawing.Color.White;
            this.guna2Panel9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(209)))), ((int)(((byte)(213)))));
            this.guna2Panel9.BorderRadius = 6;
            this.guna2Panel9.BorderThickness = 1;
            this.guna2Panel9.Controls.Add(this.guna2Panel13);
            this.guna2Panel9.Controls.Add(this.label34);
            this.guna2Panel9.Controls.Add(this.label2);
            this.guna2Panel9.Controls.Add(this.label1);
            this.guna2Panel9.Controls.Add(this.pictureBox23);
            this.guna2Panel9.Controls.Add(this.label25);
            this.guna2Panel9.Controls.Add(this.label26);
            this.guna2Panel9.Controls.Add(this.pictureBox24);
            this.guna2Panel9.Controls.Add(this.guna2Separator8);
            this.guna2Panel9.Controls.Add(this.label27);
            this.guna2Panel9.Controls.Add(this.pictureBox25);
            this.guna2Panel9.Controls.Add(this.label28);
            this.guna2Panel9.Controls.Add(this.label29);
            this.guna2Panel9.Controls.Add(this.pictureBox26);
            this.guna2Panel9.Controls.Add(this.guna2Separator9);
            this.guna2Panel9.Controls.Add(this.label30);
            this.guna2Panel9.Controls.Add(this.label31);
            this.guna2Panel9.Controls.Add(this.label32);
            this.guna2Panel9.Controls.Add(this.pictureBox27);
            this.guna2Panel9.Controls.Add(this.guna2Separator10);
            this.guna2Panel9.Controls.Add(this.label33);
            this.guna2Panel9.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(209)))), ((int)(((byte)(213)))));
            this.guna2Panel9.CustomBorderThickness = new System.Windows.Forms.Padding(1);
            this.guna2Panel9.Location = new System.Drawing.Point(28, 90);
            this.guna2Panel9.Name = "guna2Panel9";
            this.guna2Panel9.ShadowDecoration.Parent = this.guna2Panel9;
            this.guna2Panel9.Size = new System.Drawing.Size(1098, 629);
            this.guna2Panel9.TabIndex = 19;
            // 
            // guna2Panel13
            // 
            this.guna2Panel13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(255)))), ((int)(((byte)(216)))));
            this.guna2Panel13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(197)))), ((int)(((byte)(153)))));
            this.guna2Panel13.BorderRadius = 15;
            this.guna2Panel13.BorderThickness = 1;
            this.guna2Panel13.Controls.Add(this.label35);
            this.guna2Panel13.Controls.Add(this.label36);
            this.guna2Panel13.Controls.Add(this.pictureBox2);
            this.guna2Panel13.Location = new System.Drawing.Point(650, 497);
            this.guna2Panel13.Name = "guna2Panel13";
            this.guna2Panel13.ShadowDecoration.Parent = this.guna2Panel13;
            this.guna2Panel13.Size = new System.Drawing.Size(415, 90);
            this.guna2Panel13.TabIndex = 46;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(149)))), ((int)(((byte)(14)))));
            this.label35.Location = new System.Drawing.Point(22, 52);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(327, 19);
            this.label35.TabIndex = 17;
            this.label35.Text = "The changes has been saved to the database.";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(149)))), ((int)(((byte)(14)))));
            this.label36.Location = new System.Drawing.Point(22, 21);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(341, 19);
            this.label36.TabIndex = 10;
            this.label36.Text = "Notification has been removed successfully.";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::viewminder1.Properties.Resources.Vector;
            this.pictureBox2.Location = new System.Drawing.Point(374, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(28, 28);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // label34
            // 
            this.label34.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(233, 95);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(429, 19);
            this.label34.TabIndex = 45;
            this.label34.Text = " - Cam 1 | Room 3 : Motion detected at 2023-08-14 | 5: 14 PM ";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(233, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(429, 19);
            this.label2.TabIndex = 44;
            this.label2.Text = " - Cam 1 | Room 3 : Motion detected at 2023-08-14 | 5: 14 PM ";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(206, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(416, 19);
            this.label1.TabIndex = 43;
            this.label1.Text = "- New user login  : Login detected at 2023-08-14 | 5: 14 PM ";
            // 
            // pictureBox23
            // 
            this.pictureBox23.Image = global::viewminder1.Properties.Resources.carbon_checkbox;
            this.pictureBox23.Location = new System.Drawing.Point(17, 91);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(28, 28);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox23.TabIndex = 42;
            this.pictureBox23.TabStop = false;
            // 
            // label25
            // 
            this.label25.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label25.Location = new System.Drawing.Point(796, 93);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(120, 19);
            this.label25.TabIndex = 41;
            this.label25.Text = "August 20,2023";
            // 
            // label26
            // 
            this.label26.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label26.Location = new System.Drawing.Point(1018, 95);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(67, 19);
            this.label26.TabIndex = 40;
            this.label26.Text = "5:14 PM";
            // 
            // pictureBox24
            // 
            this.pictureBox24.Image = global::viewminder1.Properties.Resources.ic_round_warning;
            this.pictureBox24.Location = new System.Drawing.Point(60, 91);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(28, 28);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox24.TabIndex = 39;
            this.pictureBox24.TabStop = false;
            // 
            // guna2Separator8
            // 
            this.guna2Separator8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator8.Location = new System.Drawing.Point(3, 122);
            this.guna2Separator8.Name = "guna2Separator8";
            this.guna2Separator8.Size = new System.Drawing.Size(1092, 10);
            this.guna2Separator8.TabIndex = 38;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(94, 95);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(136, 19);
            this.label27.TabIndex = 37;
            this.label27.Text = "Motion detection";
            // 
            // pictureBox25
            // 
            this.pictureBox25.Image = global::viewminder1.Properties.Resources.ion_checkbox;
            this.pictureBox25.Location = new System.Drawing.Point(17, 49);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(28, 28);
            this.pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox25.TabIndex = 36;
            this.pictureBox25.TabStop = false;
            // 
            // label28
            // 
            this.label28.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label28.Location = new System.Drawing.Point(796, 53);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(120, 19);
            this.label28.TabIndex = 35;
            this.label28.Text = "August 20,2023";
            // 
            // label29
            // 
            this.label29.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label29.Location = new System.Drawing.Point(1018, 53);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(67, 19);
            this.label29.TabIndex = 34;
            this.label29.Text = "5:14 PM";
            // 
            // pictureBox26
            // 
            this.pictureBox26.Image = global::viewminder1.Properties.Resources.ic_round_warning;
            this.pictureBox26.Location = new System.Drawing.Point(60, 49);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(28, 28);
            this.pictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox26.TabIndex = 33;
            this.pictureBox26.TabStop = false;
            // 
            // guna2Separator9
            // 
            this.guna2Separator9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator9.Location = new System.Drawing.Point(3, 80);
            this.guna2Separator9.Name = "guna2Separator9";
            this.guna2Separator9.Size = new System.Drawing.Size(1092, 10);
            this.guna2Separator9.TabIndex = 32;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(94, 53);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(136, 19);
            this.label30.TabIndex = 31;
            this.label30.Text = "Motion detection";
            // 
            // label31
            // 
            this.label31.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label31.Location = new System.Drawing.Point(745, 11);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(120, 19);
            this.label31.TabIndex = 30;
            this.label31.Text = "August 20,2023";
            // 
            // label32
            // 
            this.label32.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(149)))), ((int)(((byte)(149)))));
            this.label32.Location = new System.Drawing.Point(1018, 11);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(67, 19);
            this.label32.TabIndex = 29;
            this.label32.Text = "5:14 PM";
            // 
            // pictureBox27
            // 
            this.pictureBox27.Image = global::viewminder1.Properties.Resources.clarity_login_solid;
            this.pictureBox27.Location = new System.Drawing.Point(17, 7);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(28, 28);
            this.pictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox27.TabIndex = 28;
            this.pictureBox27.TabStop = false;
            // 
            // guna2Separator10
            // 
            this.guna2Separator10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Separator10.Location = new System.Drawing.Point(3, 38);
            this.guna2Separator10.Name = "guna2Separator10";
            this.guna2Separator10.Size = new System.Drawing.Size(1092, 10);
            this.guna2Separator10.TabIndex = 27;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(51, 11);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(153, 19);
            this.label33.TabIndex = 26;
            this.label33.Text = "New login detected";
            // 
            // guna2HtmlLabel11
            // 
            this.guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel11.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel11.Location = new System.Drawing.Point(28, 31);
            this.guna2HtmlLabel11.Name = "guna2HtmlLabel11";
            this.guna2HtmlLabel11.Size = new System.Drawing.Size(123, 27);
            this.guna2HtmlLabel11.TabIndex = 14;
            this.guna2HtmlLabel11.Text = "Notification";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label50);
            this.tabPage5.Controls.Add(this.label51);
            this.tabPage5.Controls.Add(this.label48);
            this.tabPage5.Controls.Add(this.label49);
            this.tabPage5.Controls.Add(this.label46);
            this.tabPage5.Controls.Add(this.label47);
            this.tabPage5.Controls.Add(this.label44);
            this.tabPage5.Controls.Add(this.label45);
            this.tabPage5.Controls.Add(this.label42);
            this.tabPage5.Controls.Add(this.label43);
            this.tabPage5.Controls.Add(this.label40);
            this.tabPage5.Controls.Add(this.label41);
            this.tabPage5.Controls.Add(this.label39);
            this.tabPage5.Controls.Add(this.label38);
            this.tabPage5.Controls.Add(this.label37);
            this.tabPage5.Controls.Add(this.guna2Button4);
            this.tabPage5.Controls.Add(this.guna2HtmlLabel12);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1164, 751);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            this.tabPage5.Click += new System.EventHandler(this.TabPage5_Click);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(231, 382);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(114, 19);
            this.label50.TabIndex = 41;
            this.label50.Text = "Ilovepizza123";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(24, 382);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(87, 19);
            this.label51.TabIndex = 40;
            this.label51.Text = "Password:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(231, 335);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(49, 19);
            this.label48.TabIndex = 39;
            this.label48.Text = "1234";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(24, 335);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(37, 19);
            this.label49.TabIndex = 38;
            this.label49.Text = "Pin:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(231, 290);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(69, 19);
            this.label46.TabIndex = 37;
            this.label46.Text = "123487";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(24, 290);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(96, 19);
            this.label47.TabIndex = 36;
            this.label47.Text = "Account Id:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(231, 249);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(119, 19);
            this.label44.TabIndex = 35;
            this.label44.Text = "09564430686";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(24, 249);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(127, 19);
            this.label45.TabIndex = 34;
            this.label45.Text = "Phone Number:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(231, 206);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(250, 19);
            this.label42.TabIndex = 33;
            this.label42.Text = "stevencabugos138@gmail.com ";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(24, 206);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(120, 19);
            this.label43.TabIndex = 32;
            this.label43.Text = "Email Address:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(231, 165);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(61, 19);
            this.label40.TabIndex = 31;
            this.label40.Text = "Steven";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(24, 165);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(93, 19);
            this.label41.TabIndex = 30;
            this.label41.Text = "Username: ";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(231, 124);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(132, 19);
            this.label39.TabIndex = 29;
            this.label39.Text = "Steven Cabugos";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Aileron Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(24, 124);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(91, 19);
            this.label38.TabIndex = 28;
            this.label38.Text = "Full Name: ";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Aileron Heavy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(24, 77);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(115, 19);
            this.label37.TabIndex = 27;
            this.label37.Text = "Profile Details";
            // 
            // guna2Button4
            // 
            this.guna2Button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button4.BackColor = System.Drawing.Color.White;
            this.guna2Button4.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button4.BorderRadius = 9;
            this.guna2Button4.BorderThickness = 1;
            this.guna2Button4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button4.CheckedState.Parent = this.guna2Button4;
            this.guna2Button4.CustomImages.Parent = this.guna2Button4;
            this.guna2Button4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button4.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button4.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button4.HoverState.Parent = this.guna2Button4;
            this.guna2Button4.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button4.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button4.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button4.Location = new System.Drawing.Point(992, 40);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button4.ShadowDecoration.Parent = this.guna2Button4;
            this.guna2Button4.Size = new System.Drawing.Size(134, 34);
            this.guna2Button4.TabIndex = 25;
            this.guna2Button4.Text = "Edit Account";
            this.guna2Button4.Click += new System.EventHandler(this.Guna2Button4_Click);
            // 
            // guna2HtmlLabel12
            // 
            this.guna2HtmlLabel12.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel12.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel12.Location = new System.Drawing.Point(28, 31);
            this.guna2HtmlLabel12.Name = "guna2HtmlLabel12";
            this.guna2HtmlLabel12.Size = new System.Drawing.Size(187, 27);
            this.guna2HtmlLabel12.TabIndex = 14;
            this.guna2HtmlLabel12.Text = "Account Overview";
            this.guna2HtmlLabel12.Click += new System.EventHandler(this.Guna2HtmlLabel12_Click);
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.guna2Button15);
            this.tabPage10.Controls.Add(this.guna2TextBox7);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel16);
            this.tabPage10.Controls.Add(this.guna2TextBox6);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel17);
            this.tabPage10.Controls.Add(this.guna2TextBox5);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel18);
            this.tabPage10.Controls.Add(this.guna2TextBox4);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel19);
            this.tabPage10.Controls.Add(this.guna2TextBox3);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel20);
            this.tabPage10.Controls.Add(this.guna2TextBox2);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel21);
            this.tabPage10.Controls.Add(this.guna2TextBox1);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel22);
            this.tabPage10.Controls.Add(this.guna2Button16);
            this.tabPage10.Controls.Add(this.label52);
            this.tabPage10.Controls.Add(this.guna2HtmlLabel15);
            this.tabPage10.Controls.Add(this.guna2Button14);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(1164, 751);
            this.tabPage10.TabIndex = 5;
            this.tabPage10.Text = "tabPage10";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // guna2Button15
            // 
            this.guna2Button15.BackColor = System.Drawing.Color.White;
            this.guna2Button15.BorderRadius = 9;
            this.guna2Button15.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button15.CheckedState.Parent = this.guna2Button15;
            this.guna2Button15.CustomImages.Parent = this.guna2Button15;
            this.guna2Button15.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(241)))), ((int)(((byte)(241)))));
            this.guna2Button15.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button15.ForeColor = System.Drawing.Color.Black;
            this.guna2Button15.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button15.HoverState.Parent = this.guna2Button15;
            this.guna2Button15.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button15.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button15.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button15.Location = new System.Drawing.Point(28, 480);
            this.guna2Button15.Name = "guna2Button15";
            this.guna2Button15.PressedColor = System.Drawing.Color.White;
            this.guna2Button15.ShadowDecoration.Parent = this.guna2Button15;
            this.guna2Button15.Size = new System.Drawing.Size(208, 44);
            this.guna2Button15.TabIndex = 49;
            this.guna2Button15.Text = "Cancel";
            this.guna2Button15.Click += new System.EventHandler(this.Guna2Button15_Click);
            // 
            // guna2TextBox7
            // 
            this.guna2TextBox7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox7.BorderRadius = 6;
            this.guna2TextBox7.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox7.DefaultText = "";
            this.guna2TextBox7.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox7.DisabledState.Parent = this.guna2TextBox7;
            this.guna2TextBox7.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox7.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox7.FocusedState.Parent = this.guna2TextBox7;
            this.guna2TextBox7.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox7.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox7.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox7.HoverState.Parent = this.guna2TextBox7;
            this.guna2TextBox7.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox7.Location = new System.Drawing.Point(527, 322);
            this.guna2TextBox7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox7.Name = "guna2TextBox7";
            this.guna2TextBox7.PasswordChar = '\0';
            this.guna2TextBox7.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox7.PlaceholderText = "Enter 4 digits pin";
            this.guna2TextBox7.SelectedText = "";
            this.guna2TextBox7.ShadowDecoration.Parent = this.guna2TextBox7;
            this.guna2TextBox7.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox7.TabIndex = 48;
            // 
            // guna2HtmlLabel16
            // 
            this.guna2HtmlLabel16.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel16.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel16.Location = new System.Drawing.Point(527, 294);
            this.guna2HtmlLabel16.Name = "guna2HtmlLabel16";
            this.guna2HtmlLabel16.Size = new System.Drawing.Size(27, 21);
            this.guna2HtmlLabel16.TabIndex = 47;
            this.guna2HtmlLabel16.Text = "Pin";
            // 
            // guna2TextBox6
            // 
            this.guna2TextBox6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox6.BorderRadius = 6;
            this.guna2TextBox6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox6.DefaultText = "";
            this.guna2TextBox6.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox6.DisabledState.Parent = this.guna2TextBox6;
            this.guna2TextBox6.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox6.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox6.FocusedState.Parent = this.guna2TextBox6;
            this.guna2TextBox6.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox6.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox6.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox6.HoverState.Parent = this.guna2TextBox6;
            this.guna2TextBox6.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox6.Location = new System.Drawing.Point(527, 229);
            this.guna2TextBox6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox6.Name = "guna2TextBox6";
            this.guna2TextBox6.PasswordChar = '\0';
            this.guna2TextBox6.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox6.PlaceholderText = "Enter account Id";
            this.guna2TextBox6.SelectedText = "";
            this.guna2TextBox6.ShadowDecoration.Parent = this.guna2TextBox6;
            this.guna2TextBox6.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox6.TabIndex = 46;
            // 
            // guna2HtmlLabel17
            // 
            this.guna2HtmlLabel17.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel17.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel17.Location = new System.Drawing.Point(527, 201);
            this.guna2HtmlLabel17.Name = "guna2HtmlLabel17";
            this.guna2HtmlLabel17.Size = new System.Drawing.Size(83, 21);
            this.guna2HtmlLabel17.TabIndex = 45;
            this.guna2HtmlLabel17.Text = "Account Id";
            // 
            // guna2TextBox5
            // 
            this.guna2TextBox5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox5.BorderRadius = 6;
            this.guna2TextBox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox5.DefaultText = "";
            this.guna2TextBox5.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox5.DisabledState.Parent = this.guna2TextBox5;
            this.guna2TextBox5.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox5.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox5.FocusedState.Parent = this.guna2TextBox5;
            this.guna2TextBox5.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox5.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox5.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox5.HoverState.Parent = this.guna2TextBox5;
            this.guna2TextBox5.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox5.Location = new System.Drawing.Point(527, 140);
            this.guna2TextBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox5.Name = "guna2TextBox5";
            this.guna2TextBox5.PasswordChar = '\0';
            this.guna2TextBox5.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox5.PlaceholderText = "Enter phone number";
            this.guna2TextBox5.SelectedText = "";
            this.guna2TextBox5.ShadowDecoration.Parent = this.guna2TextBox5;
            this.guna2TextBox5.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox5.TabIndex = 44;
            // 
            // guna2HtmlLabel18
            // 
            this.guna2HtmlLabel18.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel18.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel18.Location = new System.Drawing.Point(527, 112);
            this.guna2HtmlLabel18.Name = "guna2HtmlLabel18";
            this.guna2HtmlLabel18.Size = new System.Drawing.Size(116, 21);
            this.guna2HtmlLabel18.TabIndex = 43;
            this.guna2HtmlLabel18.Text = "Phone Number";
            // 
            // guna2TextBox4
            // 
            this.guna2TextBox4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox4.BorderRadius = 6;
            this.guna2TextBox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox4.DefaultText = "";
            this.guna2TextBox4.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox4.DisabledState.Parent = this.guna2TextBox4;
            this.guna2TextBox4.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox4.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox4.FocusedState.Parent = this.guna2TextBox4;
            this.guna2TextBox4.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox4.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox4.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox4.HoverState.Parent = this.guna2TextBox4;
            this.guna2TextBox4.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox4.Location = new System.Drawing.Point(28, 411);
            this.guna2TextBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox4.Name = "guna2TextBox4";
            this.guna2TextBox4.PasswordChar = '\0';
            this.guna2TextBox4.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox4.PlaceholderText = "Enter password";
            this.guna2TextBox4.SelectedText = "";
            this.guna2TextBox4.ShadowDecoration.Parent = this.guna2TextBox4;
            this.guna2TextBox4.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox4.TabIndex = 42;
            // 
            // guna2HtmlLabel19
            // 
            this.guna2HtmlLabel19.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel19.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel19.Location = new System.Drawing.Point(28, 383);
            this.guna2HtmlLabel19.Name = "guna2HtmlLabel19";
            this.guna2HtmlLabel19.Size = new System.Drawing.Size(77, 21);
            this.guna2HtmlLabel19.TabIndex = 41;
            this.guna2HtmlLabel19.Text = "Password";
            // 
            // guna2TextBox3
            // 
            this.guna2TextBox3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.BorderRadius = 6;
            this.guna2TextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox3.DefaultText = "";
            this.guna2TextBox3.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox3.DisabledState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.FocusedState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox3.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox3.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.HoverState.Parent = this.guna2TextBox3;
            this.guna2TextBox3.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox3.Location = new System.Drawing.Point(28, 322);
            this.guna2TextBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox3.Name = "guna2TextBox3";
            this.guna2TextBox3.PasswordChar = '\0';
            this.guna2TextBox3.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox3.PlaceholderText = "Enter email address";
            this.guna2TextBox3.SelectedText = "";
            this.guna2TextBox3.ShadowDecoration.Parent = this.guna2TextBox3;
            this.guna2TextBox3.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox3.TabIndex = 40;
            // 
            // guna2HtmlLabel20
            // 
            this.guna2HtmlLabel20.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel20.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel20.Location = new System.Drawing.Point(28, 294);
            this.guna2HtmlLabel20.Name = "guna2HtmlLabel20";
            this.guna2HtmlLabel20.Size = new System.Drawing.Size(108, 21);
            this.guna2HtmlLabel20.TabIndex = 39;
            this.guna2HtmlLabel20.Text = "Email Address";
            // 
            // guna2TextBox2
            // 
            this.guna2TextBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox2.BorderRadius = 6;
            this.guna2TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox2.DefaultText = "";
            this.guna2TextBox2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2.DisabledState.Parent = this.guna2TextBox2;
            this.guna2TextBox2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox2.FocusedState.Parent = this.guna2TextBox2;
            this.guna2TextBox2.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox2.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox2.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox2.HoverState.Parent = this.guna2TextBox2;
            this.guna2TextBox2.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox2.Location = new System.Drawing.Point(28, 229);
            this.guna2TextBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox2.Name = "guna2TextBox2";
            this.guna2TextBox2.PasswordChar = '\0';
            this.guna2TextBox2.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox2.PlaceholderText = "Enter username";
            this.guna2TextBox2.SelectedText = "";
            this.guna2TextBox2.ShadowDecoration.Parent = this.guna2TextBox2;
            this.guna2TextBox2.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox2.TabIndex = 38;
            // 
            // guna2HtmlLabel21
            // 
            this.guna2HtmlLabel21.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel21.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel21.Location = new System.Drawing.Point(28, 201);
            this.guna2HtmlLabel21.Name = "guna2HtmlLabel21";
            this.guna2HtmlLabel21.Size = new System.Drawing.Size(79, 21);
            this.guna2HtmlLabel21.TabIndex = 37;
            this.guna2HtmlLabel21.Text = "Username";
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.BorderRadius = 6;
            this.guna2TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox1.DefaultText = "";
            this.guna2TextBox1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.DisabledState.Parent = this.guna2TextBox1;
            this.guna2TextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.FocusedState.Parent = this.guna2TextBox1;
            this.guna2TextBox1.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TextBox1.ForeColor = System.Drawing.Color.Black;
            this.guna2TextBox1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.HoverState.Parent = this.guna2TextBox1;
            this.guna2TextBox1.IconRightOffset = new System.Drawing.Point(10, 0);
            this.guna2TextBox1.Location = new System.Drawing.Point(28, 140);
            this.guna2TextBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.PasswordChar = '\0';
            this.guna2TextBox1.PlaceholderForeColor = System.Drawing.Color.Black;
            this.guna2TextBox1.PlaceholderText = "Enter full name";
            this.guna2TextBox1.SelectedText = "";
            this.guna2TextBox1.ShadowDecoration.Parent = this.guna2TextBox1;
            this.guna2TextBox1.Size = new System.Drawing.Size(429, 44);
            this.guna2TextBox1.TabIndex = 36;
            // 
            // guna2HtmlLabel22
            // 
            this.guna2HtmlLabel22.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel22.Font = new System.Drawing.Font("Aileron SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel22.Location = new System.Drawing.Point(28, 112);
            this.guna2HtmlLabel22.Name = "guna2HtmlLabel22";
            this.guna2HtmlLabel22.Size = new System.Drawing.Size(77, 21);
            this.guna2HtmlLabel22.TabIndex = 35;
            this.guna2HtmlLabel22.Text = "Full Name";
            // 
            // guna2Button16
            // 
            this.guna2Button16.BackColor = System.Drawing.Color.White;
            this.guna2Button16.BorderRadius = 9;
            this.guna2Button16.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button16.CheckedState.Parent = this.guna2Button16;
            this.guna2Button16.CustomImages.Parent = this.guna2Button16;
            this.guna2Button16.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button16.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button16.ForeColor = System.Drawing.Color.White;
            this.guna2Button16.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(12)))), ((int)(((byte)(41)))));
            this.guna2Button16.HoverState.Parent = this.guna2Button16;
            this.guna2Button16.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button16.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button16.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button16.Location = new System.Drawing.Point(249, 480);
            this.guna2Button16.Name = "guna2Button16";
            this.guna2Button16.ShadowDecoration.Parent = this.guna2Button16;
            this.guna2Button16.Size = new System.Drawing.Size(208, 44);
            this.guna2Button16.TabIndex = 34;
            this.guna2Button16.Text = "Confirm";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Aileron Heavy", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(24, 77);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(115, 19);
            this.label52.TabIndex = 28;
            this.label52.Text = "Profile Details";
            // 
            // guna2HtmlLabel15
            // 
            this.guna2HtmlLabel15.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel15.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel15.Location = new System.Drawing.Point(28, 31);
            this.guna2HtmlLabel15.Name = "guna2HtmlLabel15";
            this.guna2HtmlLabel15.Size = new System.Drawing.Size(187, 27);
            this.guna2HtmlLabel15.TabIndex = 27;
            this.guna2HtmlLabel15.Text = "Account Overview";
            // 
            // guna2Button14
            // 
            this.guna2Button14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button14.BackColor = System.Drawing.Color.White;
            this.guna2Button14.BorderColor = System.Drawing.Color.Gainsboro;
            this.guna2Button14.BorderRadius = 9;
            this.guna2Button14.BorderThickness = 1;
            this.guna2Button14.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button14.CheckedState.Parent = this.guna2Button14;
            this.guna2Button14.CustomImages.Parent = this.guna2Button14;
            this.guna2Button14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button14.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(147)))), ((int)(((byte)(254)))));
            this.guna2Button14.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button14.HoverState.Parent = this.guna2Button14;
            this.guna2Button14.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button14.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button14.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button14.Location = new System.Drawing.Point(992, 40);
            this.guna2Button14.Name = "guna2Button14";
            this.guna2Button14.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button14.ShadowDecoration.Parent = this.guna2Button14;
            this.guna2Button14.Size = new System.Drawing.Size(134, 34);
            this.guna2Button14.TabIndex = 26;
            this.guna2Button14.Text = "Edit Account";
            // 
            // pnlContent
            // 
            this.pnlContent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(246)))), ((int)(((byte)(248)))));
            this.pnlContent.Controls.Add(this.guna2Panel25);
            this.pnlContent.Controls.Add(this.flowLayoutPanel1);
            this.pnlContent.Controls.Add(this.tabControl1);
            this.pnlContent.Controls.Add(this.monthCalendar1);
            this.pnlContent.Controls.Add(this.guna2Panel3);
            this.pnlContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContent.Location = new System.Drawing.Point(244, 20);
            this.pnlContent.Name = "pnlContent";
            this.pnlContent.ShadowDecoration.Parent = this.pnlContent;
            this.pnlContent.Size = new System.Drawing.Size(1229, 838);
            this.pnlContent.TabIndex = 6;
            this.pnlContent.Paint += new System.Windows.Forms.PaintEventHandler(this.PnlContent_Paint);
            // 
            // guna2Panel25
            // 
            this.guna2Panel25.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Panel25.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Panel25.BorderRadius = 6;
            this.guna2Panel25.BorderThickness = 1;
            this.guna2Panel25.Controls.Add(this.guna2Button22);
            this.guna2Panel25.Controls.Add(this.guna2Button21);
            this.guna2Panel25.Controls.Add(this.guna2Button20);
            this.guna2Panel25.Controls.Add(this.guna2Button19);
            this.guna2Panel25.Controls.Add(this.pictureBox1);
            this.guna2Panel25.Controls.Add(this.guna2Button18);
            this.guna2Panel25.Location = new System.Drawing.Point(985, 50);
            this.guna2Panel25.Name = "guna2Panel25";
            this.guna2Panel25.ShadowDecoration.Parent = this.guna2Panel25;
            this.guna2Panel25.Size = new System.Drawing.Size(211, 289);
            this.guna2Panel25.TabIndex = 37;
            this.guna2Panel25.Visible = false;
            // 
            // guna2Button22
            // 
            this.guna2Button22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button22.BackColor = System.Drawing.Color.White;
            this.guna2Button22.BorderColor = System.Drawing.Color.Transparent;
            this.guna2Button22.BorderThickness = 1;
            this.guna2Button22.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button22.CheckedState.Parent = this.guna2Button22;
            this.guna2Button22.CustomImages.Parent = this.guna2Button22;
            this.guna2Button22.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button22.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button22.ForeColor = System.Drawing.Color.Black;
            this.guna2Button22.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button22.HoverState.Parent = this.guna2Button22;
            this.guna2Button22.Image = global::viewminder1.Properties.Resources.ic_baseline_logout1;
            this.guna2Button22.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button22.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button22.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button22.Location = new System.Drawing.Point(1, 229);
            this.guna2Button22.Name = "guna2Button22";
            this.guna2Button22.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button22.ShadowDecoration.Parent = this.guna2Button22;
            this.guna2Button22.Size = new System.Drawing.Size(209, 44);
            this.guna2Button22.TabIndex = 29;
            this.guna2Button22.Text = "Logout";
            this.guna2Button22.TextOffset = new System.Drawing.Point(-15, 0);
            this.guna2Button22.Click += new System.EventHandler(this.Guna2Button22_Click);
            // 
            // guna2Button21
            // 
            this.guna2Button21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button21.BackColor = System.Drawing.Color.White;
            this.guna2Button21.BorderColor = System.Drawing.Color.Transparent;
            this.guna2Button21.BorderThickness = 1;
            this.guna2Button21.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button21.CheckedState.Parent = this.guna2Button21;
            this.guna2Button21.CustomImages.Parent = this.guna2Button21;
            this.guna2Button21.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button21.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button21.ForeColor = System.Drawing.Color.Black;
            this.guna2Button21.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button21.HoverState.Parent = this.guna2Button21;
            this.guna2Button21.Image = global::viewminder1.Properties.Resources.material_symbols_archive1;
            this.guna2Button21.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button21.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button21.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button21.Location = new System.Drawing.Point(1, 180);
            this.guna2Button21.Name = "guna2Button21";
            this.guna2Button21.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button21.ShadowDecoration.Parent = this.guna2Button21;
            this.guna2Button21.Size = new System.Drawing.Size(209, 44);
            this.guna2Button21.TabIndex = 28;
            this.guna2Button21.Text = "Archive";
            this.guna2Button21.TextOffset = new System.Drawing.Point(-14, 0);
            this.guna2Button21.Click += new System.EventHandler(this.Guna2Button21_Click);
            // 
            // guna2Button20
            // 
            this.guna2Button20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button20.BackColor = System.Drawing.Color.White;
            this.guna2Button20.BorderColor = System.Drawing.Color.Transparent;
            this.guna2Button20.BorderThickness = 1;
            this.guna2Button20.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button20.CheckedState.Parent = this.guna2Button20;
            this.guna2Button20.CustomImages.Parent = this.guna2Button20;
            this.guna2Button20.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button20.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button20.ForeColor = System.Drawing.Color.Black;
            this.guna2Button20.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button20.HoverState.Parent = this.guna2Button20;
            this.guna2Button20.Image = global::viewminder1.Properties.Resources.ic_sharp_textsms;
            this.guna2Button20.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button20.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button20.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button20.Location = new System.Drawing.Point(1, 130);
            this.guna2Button20.Name = "guna2Button20";
            this.guna2Button20.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button20.ShadowDecoration.Parent = this.guna2Button20;
            this.guna2Button20.Size = new System.Drawing.Size(209, 44);
            this.guna2Button20.TabIndex = 27;
            this.guna2Button20.Text = "Messages";
            this.guna2Button20.TextOffset = new System.Drawing.Point(-7, 0);
            this.guna2Button20.Click += new System.EventHandler(this.Guna2Button20_Click);
            // 
            // guna2Button19
            // 
            this.guna2Button19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button19.BackColor = System.Drawing.Color.White;
            this.guna2Button19.BorderColor = System.Drawing.Color.Transparent;
            this.guna2Button19.BorderThickness = 1;
            this.guna2Button19.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button19.CheckedState.Parent = this.guna2Button19;
            this.guna2Button19.CustomImages.Parent = this.guna2Button19;
            this.guna2Button19.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button19.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button19.ForeColor = System.Drawing.Color.Black;
            this.guna2Button19.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button19.HoverState.Parent = this.guna2Button19;
            this.guna2Button19.Image = global::viewminder1.Properties.Resources.carbon_view_filled1;
            this.guna2Button19.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button19.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button19.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button19.Location = new System.Drawing.Point(1, 82);
            this.guna2Button19.Name = "guna2Button19";
            this.guna2Button19.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button19.ShadowDecoration.Parent = this.guna2Button19;
            this.guna2Button19.Size = new System.Drawing.Size(209, 44);
            this.guna2Button19.TabIndex = 26;
            this.guna2Button19.Text = "Watching";
            this.guna2Button19.TextOffset = new System.Drawing.Point(-8, 0);
            this.guna2Button19.Click += new System.EventHandler(this.Guna2Button19_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::viewminder1.Properties.Resources.close;
            this.pictureBox1.Location = new System.Drawing.Point(180, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(28, 28);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.PictureBox1_Click_1);
            // 
            // guna2Button18
            // 
            this.guna2Button18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2Button18.BackColor = System.Drawing.Color.White;
            this.guna2Button18.BorderColor = System.Drawing.Color.Transparent;
            this.guna2Button18.BorderThickness = 1;
            this.guna2Button18.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(129)))), ((int)(((byte)(255)))));
            this.guna2Button18.CheckedState.Parent = this.guna2Button18;
            this.guna2Button18.CustomImages.Parent = this.guna2Button18;
            this.guna2Button18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(248)))), ((int)(((byte)(250)))));
            this.guna2Button18.Font = new System.Drawing.Font("Aileron", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button18.ForeColor = System.Drawing.Color.Black;
            this.guna2Button18.HoverState.FillColor = System.Drawing.Color.LightGray;
            this.guna2Button18.HoverState.Parent = this.guna2Button18;
            this.guna2Button18.Image = global::viewminder1.Properties.Resources.ic_baseline_account_circle1;
            this.guna2Button18.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button18.ImageOffset = new System.Drawing.Point(16, 0);
            this.guna2Button18.ImageSize = new System.Drawing.Size(16, 16);
            this.guna2Button18.Location = new System.Drawing.Point(1, 34);
            this.guna2Button18.Name = "guna2Button18";
            this.guna2Button18.PressedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Button18.ShadowDecoration.Parent = this.guna2Button18;
            this.guna2Button18.Size = new System.Drawing.Size(209, 44);
            this.guna2Button18.TabIndex = 24;
            this.guna2Button18.Text = "View Profile";
            this.guna2Button18.Click += new System.EventHandler(this.Guna2Button18_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.Location = new System.Drawing.Point(412, 49);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(781, 26);
            this.flowLayoutPanel1.TabIndex = 20;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Aileron Bold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(28, 72);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(81, 27);
            this.guna2HtmlLabel1.TabIndex = 11;
            this.guna2HtmlLabel1.Text = "Camera";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1473, 858);
            this.Controls.Add(this.pnlContent);
            this.Controls.Add(this.guna2HtmlLabel3);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.btnPanel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.btnPanel.ResumeLayout(false);
            this.btnPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel3.ResumeLayout(false);
            this.guna2Panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox7)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox15)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox6)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox11)).EndInit();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox19)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.guna2Panel7.ResumeLayout(false);
            this.guna2Panel7.PerformLayout();
            this.guna2Panel11.ResumeLayout(false);
            this.guna2Panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.guna2Panel8.ResumeLayout(false);
            this.guna2Panel8.PerformLayout();
            this.guna2Panel12.ResumeLayout(false);
            this.guna2Panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.guna2Panel9.ResumeLayout(false);
            this.guna2Panel9.PerformLayout();
            this.guna2Panel13.ResumeLayout(false);
            this.guna2Panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            this.pnlContent.ResumeLayout(false);
            this.guna2Panel25.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel btnPanel;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox2;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox3;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Guna.UI2.WinForms.Guna2Button btnWatching;
        private Guna.UI2.WinForms.Guna2Button btnSms;
        private Guna.UI2.WinForms.Guna2Button btnArchive;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private Guna.UI2.WinForms.Guna2Panel pnlContent;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage6;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox12;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox13;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox14;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox15;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private System.Windows.Forms.TabPage tabPage3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox5;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox8;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox9;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox10;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox11;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox16;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox17;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox18;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox19;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private System.Windows.Forms.TabControl tabControl1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel11;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel12;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.MonthCalendar monthCalendar2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel13;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel14;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel7;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel8;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel9;
        private System.Windows.Forms.PictureBox pictureBox11;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox12;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2Button guna2Button9;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox13;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox16;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel11;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button guna2Button10;
        private Guna.UI2.WinForms.Guna2Button guna2Button11;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel12;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.PictureBox pictureBox21;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator7;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox18;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator6;
        private System.Windows.Forms.Label label19;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button12;
        private Guna.UI2.WinForms.Guna2Button guna2Button13;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.PictureBox pictureBox24;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator8;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.PictureBox pictureBox26;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator9;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.PictureBox pictureBox27;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator10;
        private System.Windows.Forms.Label label33;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel13;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.Label label52;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel15;
        private Guna.UI2.WinForms.Guna2Button guna2Button14;
        private Guna.UI2.WinForms.Guna2Button guna2Button15;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel16;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel17;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel18;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel19;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel20;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel21;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel22;
        private Guna.UI2.WinForms.Guna2Button guna2Button16;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel17;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel15;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel23;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel16;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel24;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel14;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel10;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel18;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel19;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel25;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel20;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel26;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel21;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel22;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel23;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel24;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel28;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel26;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel27;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel25;
        private Guna.UI2.WinForms.Guna2Button guna2Button22;
        private Guna.UI2.WinForms.Guna2Button guna2Button21;
        private Guna.UI2.WinForms.Guna2Button guna2Button20;
        private Guna.UI2.WinForms.Guna2Button guna2Button19;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2Button guna2Button18;
    }
}

